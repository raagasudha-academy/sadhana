// src/recurringClasses.ts
import { randomUUID as randomUUID2 } from "node:crypto";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, QueryCommand, TransactWriteCommand } from "@aws-sdk/lib-dynamodb";

// src/model.ts
import { randomUUID } from "node:crypto";
var INSTITUTIONS = Object.freeze(["raaga", "sruti"]);
var RESOURCES = Object.freeze(["families", "students", "classes", "venues", "enrolments", "practice"]);
var isoDate = (s) => typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(`${s}T12:00:00Z`)) && (/* @__PURE__ */ new Date(`${s}T12:00:00Z`)).toISOString().startsWith(s);
var one = (value, allowed) => allowed.includes(value) ? value : null;
var clean = (text) => String(text ?? "").trim().replace(/\s+/g, " ");
var newId = (type) => `${type}-${randomUUID()}`;
var groupsFromClaims = (claims) => {
  const raw = claims?.["cognito:groups"] ?? [];
  return (Array.isArray(raw) ? raw : String(raw).replace(/[\[\]"']/g, "").split(/[\s,]+/)).filter(Boolean);
};
var ADMIN_GROUPS = Object.freeze({ raaga: "raagasudha-admin", sruti: "sruti-admin" });
var VIEWER_GROUPS = Object.freeze({ raaga: "raagasudha-viewer", sruti: "sruti-viewer" });
function permittedInstitutions(claims) {
  const groups = groupsFromClaims(claims);
  return INSTITUTIONS.filter((inst) => groups.includes(ADMIN_GROUPS[inst]));
}
function viewableInstitutions(claims) {
  const groups = groupsFromClaims(claims);
  return INSTITUTIONS.filter((inst) => groups.includes(ADMIN_GROUPS[inst]) || groups.includes(VIEWER_GROUPS[inst]));
}
function demandViewInstitution(claims, requested) {
  if (!one(requested, INSTITUTIONS)) throw httpError(400, "Select a valid institution.");
  if (!viewableInstitutions(claims).includes(requested)) throw httpError(403, "You do not have access to this institution.");
  return requested;
}
function demandAnyStaff(claims) {
  if (!viewableInstitutions(claims).length) throw httpError(403, "Staff access required.");
}
function demandInstitution(claims, requested) {
  if (!one(requested, INSTITUTIONS)) throw httpError(400, "Select a valid institution.");
  if (!permittedInstitutions(claims).includes(requested)) throw httpError(403, "You are not an administrator of this institution.");
  return requested;
}
function demandAnyAdmin(claims) {
  if (!permittedInstitutions(claims).length) throw httpError(403, "Administrator access required.");
}
function httpError(status, message) {
  const e = new Error(message);
  e.status = status;
  return e;
}
function fieldsOnly(body, keys) {
  if (!body || typeof body !== "object" || Array.isArray(body)) throw httpError(400, "Expected a JSON object.");
  const extra = Object.keys(body).filter((k) => !keys.includes(k));
  if (extra.length) throw httpError(400, `Unknown field(s): ${extra.join(", ")}`);
  return structuredClone(body);
}
var ALLOWED_FIELDS = {
  families: ["parentName", "phone", "createdIn"],
  students: ["name", "phone", "familyId", "registrationType", "adultConfirmed", "createdIn"],
  classes: ["institution", "name", "teacher", "teacherUserId", "day", "time", "duration", "mode", "venueId", "startDate", "endDate"],
  venues: ["name", "location", "address", "postcode", "notes"],
  enrolments: ["institution", "studentId", "classId", "startDate", "endDate"],
  practice: ["institution", "studentId", "date", "didPractice", "minutes", "comments", "reason"]
};
function validate(resource, draft, { creating = true } = {}) {
  if (!RESOURCES.includes(resource)) throw httpError(404, "Unknown resource.");
  const d = fieldsOnly(draft, ALLOWED_FIELDS[resource]);
  const str = (v, n) => clean(v).slice(0, n);
  if (resource === "families") {
    d.parentName = str(d.parentName, 100);
    d.phone = str(d.phone, 32);
    if (!d.parentName || !/^\+[1-9]\d{7,14}$/.test(d.phone)) throw httpError(400, "A parent name and valid international phone number are required.");
    if (!INSTITUTIONS.includes(d.createdIn)) throw httpError(400, "Invalid registration institution.");
  }
  if (resource === "students") {
    d.name = str(d.name, 100);
    d.phone = str(d.phone, 32);
    d.familyId = str(d.familyId, 80);
    if (!d.name || !INSTITUTIONS.includes(d.createdIn)) throw httpError(400, "Student name and institution are required.");
    if (d.phone && !/^\+[1-9]\d{7,14}$/.test(d.phone)) throw httpError(400, "Invalid student phone.");
    if (d.registrationType === "independent") {
      if (d.familyId || d.adultConfirmed !== true || !d.phone) throw httpError(400, "Independent registration requires confirmation of adulthood and a student phone number.");
    } else if (d.registrationType === "family") {
      if (!d.familyId) throw httpError(400, "Family-linked students require a Family ID.");
    } else throw httpError(400, "Choose family or independent registration.");
  }
  if (resource === "classes") {
    d.name = str(d.name, 100);
    d.teacher = str(d.teacher, 100);
    d.teacherUserId = str(d.teacherUserId, 100);
    if (!INSTITUTIONS.includes(d.institution) || !d.name || !d.teacher) throw httpError(400, "Class institution, name and teacher are required.");
    if (!Number.isInteger(d.day) || d.day < 0 || d.day > 6 || !/^([01]\d|2[0-3]):[0-5]\d$/.test(d.time)) throw httpError(400, "Invalid UK weekly class day/time.");
    if (!Number.isInteger(d.duration) || d.duration < 15 || d.duration > 360) throw httpError(400, "Duration must be 15\u2013360 minutes.");
    if (!["Online", "In Person"].includes(d.mode)) throw httpError(400, "Invalid delivery mode.");
    if (d.mode === "In Person" && !d.venueId) throw httpError(400, "An in-person class requires a Venue ID.");
    if (d.mode === "Online") d.venueId = "";
    if (!isoDate(d.startDate) || d.endDate && !isoDate(d.endDate) || d.endDate && d.endDate < d.startDate) throw httpError(400, "Invalid class date range.");
  }
  if (resource === "venues") {
    for (const k of ["name", "location", "address", "postcode", "notes"]) {
      if (d[k] !== void 0 && typeof d[k] !== "string") throw httpError(400, `Venue ${k} must be text.`);
      d[k] = str(d[k], k === "address" ? 240 : k === "notes" ? 500 : k === "postcode" ? 20 : 100);
    }
    if (!d.name || !d.location || !d.address) throw httpError(400, "Venue name, town and address are required.");
    if (d.postcode && !/^[a-z0-9 ]{3,20}$/i.test(d.postcode)) throw httpError(400, "Invalid postcode.");
  }
  if (resource === "enrolments") {
    d.studentId = str(d.studentId, 90);
    d.classId = str(d.classId, 90);
    if (!INSTITUTIONS.includes(d.institution) || !d.studentId || !d.classId) throw httpError(400, "Institution, student and class are required.");
    if (!isoDate(d.startDate) || d.endDate && !isoDate(d.endDate) || d.endDate && d.endDate < d.startDate) throw httpError(400, "Invalid enrolment dates.");
  }
  if (resource === "practice") {
    d.studentId = str(d.studentId, 90);
    d.comments = str(d.comments, 800);
    d.reason = str(d.reason, 300);
    if (!INSTITUTIONS.includes(d.institution) || !d.studentId || !isoDate(d.date)) throw httpError(400, "Student, institution and practice date are required.");
    if (typeof d.didPractice !== "boolean") throw httpError(400, "Specify whether practice occurred.");
    if (d.didPractice && (!Number.isInteger(d.minutes) || d.minutes < 1 || d.minutes > 1440)) throw httpError(400, "Practice minutes must be 1\u20131440.");
    if (!d.didPractice) d.minutes = 0;
    if (!d.reason) throw httpError(400, "A reason for an administrator-recorded entry is required.");
  }
  return d;
}
function directoryFor(resource, d) {
  if (resource === "families") return { GSI1PK: "DIRECTORY#FAMILY", GSI1SK: `NAME#${d.parentName.toLocaleLowerCase("en-GB")}#${d.id}`, GSI2PK: `PHONE#${d.phone}`, GSI2SK: `FAMILY#${d.id}` };
  if (resource === "students") return { GSI1PK: "DIRECTORY#STUDENT", GSI1SK: `NAME#${d.name.toLocaleLowerCase("en-GB")}#${d.id}`, ...d.phone ? { GSI2PK: `PHONE#${d.phone}`, GSI2SK: `STUDENT#${d.id}` } : {} };
  if (resource === "classes") return { GSI1PK: `INST#${d.institution}#CLASS`, GSI1SK: `NAME#${d.name.toLocaleLowerCase("en-GB")}#${d.id}` };
  if (resource === "venues") return { GSI1PK: "DIRECTORY#VENUE", GSI1SK: `NAME#${d.name.toLocaleLowerCase("en-GB")}#${d.id}` };
  if (resource === "enrolments") return { GSI1PK: `INST#${d.institution}#ENROLMENT`, GSI1SK: `STUDENT#${d.studentId}#${d.startDate}#${d.id}`, GSI2PK: `CLASS#${d.classId}`, GSI2SK: `STUDENT#${d.studentId}#${d.id}` };
  if (resource === "practice") return { GSI1PK: `INST#${d.institution}#PRACTICE`, GSI1SK: `DATE#${d.date}#STUDENT#${d.studentId}` };
  return {};
}
function keyFor(resource, d) {
  if (resource === "practice") return { PK: `PRACTICE#${d.institution}#${d.studentId}`, SK: `DATE#${d.date}` };
  const type = resource.slice(0, -1).toUpperCase();
  if (resource === "classes") return { PK: `CLASS#${d.id}`, SK: "META" };
  if (resource === "enrolments") return { PK: `ENROLMENT#${d.id}`, SK: "META" };
  if (resource === "families") return { PK: `FAMILY#${d.id}`, SK: "META" };
  if (resource === "students") return { PK: `STUDENT#${d.id}`, SK: "META" };
  if (resource === "venues") return { PK: `VENUE#${d.id}`, SK: "META" };
  throw httpError(404, `Unknown resource ${type}`);
}
function publicRecord(item) {
  if (!item) return null;
  const { PK, SK, GSI1PK, GSI1SK, GSI2PK, GSI2SK, entityType, ...body } = item;
  return body;
}

// src/scheduleModel.ts
var schedulePK = (inst) => `SCHEDULE#${inst}`;
var scheduleSK = (id) => `RECORD#${id}`;
var timePattern = /^([01]\d|2[0-3]):[0-5]\d$/;
var timeToMinutes = (s) => {
  const [h, m] = s.split(":").map(Number);
  return h * 60 + m;
};
function validateScheduleRecord(x) {
  if (!x || typeof x !== "object" || Array.isArray(x)) throw httpError(400, "Expected a schedule record.");
  if (!["raaga", "sruti", "shared"].includes(x.institution) || !["class", "class-session", "holiday", "special-event"].includes(x.recordType)) throw httpError(400, "Invalid institution or record type.");
  if (typeof x.id !== "string" || !/^[-a-zA-Z0-9]{4,90}$/.test(x.id)) throw httpError(400, "Invalid Sadhana record ID.");
  if (typeof x.name !== "string" || !x.name.trim() || x.name.length > 180) throw httpError(400, "Valid event name required.");
  for (const k of ["programme", "teacher", "mode", "location", "startTime", "endTime"]) if (typeof x[k] !== "string") throw httpError(400, `Invalid ${k}.`);
  if (x.programme.length > 100 || x.teacher.length > 120 || x.mode.length > 30 || x.location.length > 300) throw httpError(400, "One or more event fields are too long.");
  if (x.teacherId !== void 0 && (typeof x.teacherId !== "string" || !/^TEACHER-[0-9a-f-]{36}$/i.test(x.teacherId))) throw httpError(400, "Invalid linked teacher ID.");
  if (x.timezone !== "Europe/London") throw httpError(400, "Calendar timezone must be Europe/London.");
  if (x.recordType === "class") {
    if (!timePattern.test(x.startTime) || !timePattern.test(x.endTime) || timeToMinutes(x.endTime) <= timeToMinutes(x.startTime)) throw httpError(400, "Invalid master class time.");
    if (x.date || x.allDay || x.classId) throw httpError(400, "Master classes do not have a date or parent class.");
  } else {
    if (!x.date || !isoDate(x.date) || !x.endDate || !isoDate(x.endDate)) throw httpError(400, "Valid date and end date are required.");
    if (x.allDay) {
      if (x.startTime || x.endTime || x.endDate <= x.date) throw httpError(400, "All-day end date must be exclusive and after start date.");
    } else if (x.endDate !== x.date || !timePattern.test(x.startTime) || !timePattern.test(x.endTime) || timeToMinutes(x.endTime) <= timeToMinutes(x.startTime)) {
      throw httpError(400, "Timed events must have a valid same-day time range.");
    }
    if (!["confirmed", "tentative", "cancelled"].includes(x.status || "")) throw httpError(400, "Invalid session status.");
  }
  if (x.recordType === "class-session" && !x.classId) throw httpError(400, "Session must link to a master class.");
  if (x.recordType !== "class-session" && x.classId) throw httpError(400, "Only sessions may link to a master class.");
  if (x.recordType === "holiday" && x.affectsClasses !== false) throw httpError(400, "Imported holidays are informational until explicitly applied.");
  return x;
}
var scheduleFields = ["name", "programme", "teacher", "mode", "location", "date", "endDate", "startTime", "endTime", "status", "allDay", "teacherId"];
function scheduleChanges(current, raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw httpError(400, "Expected a schedule edit.");
  const extra = Object.keys(raw).filter((k) => k !== "expectedVersion" && !scheduleFields.includes(k));
  if (extra.length) throw httpError(400, `Fields cannot be changed: ${extra.join(", ")}`);
  const next = { ...current };
  for (const key of scheduleFields) if (Object.prototype.hasOwnProperty.call(raw, key)) next[key] = raw[key];
  return validateScheduleRecord(next);
}

// src/recurringClasses.ts
var db = DynamoDBDocumentClient.from(new DynamoDBClient({}), { marshallOptions: { removeUndefinedValues: true } });
var table = () => {
  if (!process.env.SADHANA_TABLE_NAME) throw Error("Missing Sadhana table");
  return process.env.SADHANA_TABLE_NAME;
};
var iso = /^\d{4}-\d{2}-\d{2}$/;
function day(s) {
  if (!iso.test(s)) throw httpError(400, "Invalid date.");
  const d = /* @__PURE__ */ new Date(`${s}T12:00:00Z`);
  if (!Number.isFinite(d.getTime()) || d.toISOString().slice(0, 10) !== s) throw httpError(400, "Invalid date.");
  return d;
}
var fmt = (d) => d.toISOString().slice(0, 10);
var plus = (d, n) => {
  const r = new Date(d);
  r.setUTCDate(r.getUTCDate() + n);
  return r;
};
function recurrenceDates(first, r) {
  const firstDay = day(first);
  if (!["daily", "weekly", "monthly"].includes(r.frequency) || !Number.isInteger(r.interval) || r.interval < 1 || r.interval > 12) throw httpError(400, "Invalid recurrence interval.");
  if (r.endMode !== "date" && r.endMode !== "count") throw httpError(400, "Choose an ending condition.");
  const end = r.endMode === "date" ? day(String(r.until)) : plus(firstDay, 730);
  if (end < firstDay || end > plus(firstDay, 730)) throw httpError(400, "Ending date must be within two years of the first class.");
  if (r.endMode === "count" && (!Number.isInteger(r.count) || r.count < 1 || r.count > 80)) throw httpError(400, "Choose between 1 and 80 sessions.");
  const weekdays = r.weekdays || [];
  if (r.frequency === "weekly" && (!weekdays.length || weekdays.length > 7 || new Set(weekdays).size !== weekdays.length || weekdays.some((n) => !Number.isInteger(n) || n < 0 || n > 6))) throw httpError(400, "Select at least one valid weekday.");
  const result = [];
  for (let offset = 0; offset <= 730; offset++) {
    const current = plus(firstDay, offset);
    if (current > end) break;
    let matches = false;
    if (r.frequency === "daily") matches = offset % r.interval === 0;
    if (r.frequency === "weekly") matches = Math.floor(offset / 7) % r.interval === 0 && weekdays.includes(current.getUTCDay());
    if (r.frequency === "monthly") {
      const months = (current.getUTCFullYear() - firstDay.getUTCFullYear()) * 12 + current.getUTCMonth() - firstDay.getUTCMonth();
      matches = months % r.interval === 0 && current.getUTCDate() === firstDay.getUTCDate();
    }
    if (matches) {
      result.push(fmt(current));
      if (result.length > 80) throw httpError(400, "Maximum 80 sessions per class. Shorten the recurrence.");
      if (r.endMode === "count" && result.length === r.count) break;
    }
  }
  if (!result.length || result[0] !== first) throw httpError(400, "First class date must match your chosen recurrence days.");
  if (r.endMode === "count" && result.length !== r.count) throw httpError(400, "Could not generate the requested sessions within two years.");
  return result;
}
function parse(inst, claims, body) {
  if (!permittedInstitutions(claims).includes(inst)) throw httpError(403, "Academy administrator required to create recurring classes.");
  if (!body || typeof body !== "object" || Array.isArray(body)) throw httpError(400, "Invalid class.");
  const allowed = ["name", "programme", "teacherId", "mode", "venueId", "location", "date", "startTime", "endTime", "recurrence"];
  if (Object.keys(body).some((k) => !allowed.includes(k))) throw httpError(400, "Unexpected class fields.");
  if (typeof body.name !== "string" || !body.name.trim() || body.name.length > 150) throw httpError(400, "Enter a class name.");
  if (!(inst === "raaga" ? ["Singing"] : ["Vedam", "Vedanta"]).includes(body.programme)) throw httpError(400, "Invalid academy programme.");
  if (typeof body.teacherId !== "string" || !/^TEACHER-[0-9a-f-]{36}$/i.test(body.teacherId)) throw httpError(400, "Choose a teacher.");
  if (!["Online", "In person"].includes(body.mode) || typeof body.venueId !== "string" || typeof body.location !== "string") throw httpError(400, "Invalid delivery or venue.");
  if (body.mode === "Online" && (body.venueId !== "" || body.location !== "Online")) throw httpError(400, "Online classes must use Online as the venue.");
  if (body.mode === "In person" && (!body.venueId || !body.location)) throw httpError(400, "Choose a saved venue.");
  if (typeof body.startTime !== "string" || typeof body.endTime !== "string" || !/^([01]\d|2[0-3]):[0-5]\d$/.test(body.startTime) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(body.endTime) || body.startTime >= body.endTime) throw httpError(400, "Invalid class times.");
  const dates = recurrenceDates(body.date, body.recurrence);
  return { dates, body };
}
async function inspect(inst, body, dates) {
  const teacher = await db.send(new GetCommand({ TableName: table(), Key: { PK: "TEACHER_REGISTRY", SK: `TEACHER#${body.teacherId}` }, ConsistentRead: true }));
  if (!teacher.Item?.active || !teacher.Item.institutions?.includes(inst)) throw httpError(400, "Teacher is not active in this academy.");
  const records = [];
  let key;
  do {
    const r = await db.send(new QueryCommand({ TableName: table(), KeyConditionExpression: "PK=:pk", ExpressionAttributeValues: { ":pk": schedulePK(inst) }, ExclusiveStartKey: key, Limit: 250 }));
    records.push(...r.Items || []);
    key = r.LastEvaluatedKey;
    if (records.length > 3e3) throw httpError(413, "Too many calendar entries.");
  } while (key);
  const candidates = records.filter((x) => x.recordType === "class" && String(x.name).trim().toLocaleLowerCase() === body.name.trim().toLocaleLowerCase());
  return { teacher: teacher.Item, duplicateNames: candidates.map((x) => ({ id: x.id, name: x.name })), dates };
}
async function previewRecurringClass(inst, claims, body) {
  const { dates } = parse(inst, claims, body);
  const found = await inspect(inst, body, dates);
  return { dates, count: dates.length, duplicateNames: found.duplicateNames, first: dates[0], last: dates.at(-1) };
}
async function createRecurringClass(inst, claims, body) {
  const { dates } = parse(inst, claims, body);
  const found = await inspect(inst, body, dates);
  if (found.duplicateNames.length) throw httpError(409, "A master class with this name already exists. Rename the class or review the existing class.");
  const classId = `CLASS-${randomUUID2()}`;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const common = { institution: inst, name: body.name.trim(), programme: body.programme, teacher: found.teacher.displayName, teacherId: body.teacherId, mode: body.mode, location: body.location, venueId: body.venueId, startTime: body.startTime, endTime: body.endTime, timezone: "Europe/London", status: "confirmed", version: 1, createdAt: now, updatedAt: now };
  const master = { ...common, id: classId, recordType: "class", date: dates[0], endDate: dates.at(-1), recurrence: body.recurrence };
  const sessions = dates.map((d) => ({ ...common, id: `EVT-${randomUUID2()}`, recordType: "class-session", classId, date: d, endDate: d, allDay: false }));
  const writes = [master, ...sessions].map((record) => ({ Put: { TableName: table(), Item: { PK: schedulePK(inst), SK: scheduleSK(record.id), entityType: "schedule", ...record }, ConditionExpression: "attribute_not_exists(PK)" } }));
  try {
    await db.send(new TransactWriteCommand({ TransactItems: writes, ClientRequestToken: void 0 }));
  } catch (e) {
    if (e.name === "TransactionCanceledException") throw httpError(409, "Class creation conflicted with another write. Nothing was created.");
    throw e;
  }
  return { record: master, sessionCount: sessions.length, dates };
}

// src/repository.ts
import { DynamoDBClient as DynamoDBClient2 } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient as DynamoDBDocumentClient2, GetCommand as GetCommand2, QueryCommand as QueryCommand2, TransactWriteCommand as TransactWriteCommand2 } from "@aws-sdk/lib-dynamodb";
var SadhanaRepository = class {
  tableName;
  client;
  constructor({ tableName = process.env.SADHANA_TABLE_NAME, region = process.env.AWS_REGION, client } = {}) {
    if (!tableName) throw new Error("SADHANA_TABLE_NAME is required");
    this.tableName = tableName;
    this.client = client ?? DynamoDBDocumentClient2.from(new DynamoDBClient2({ region }), { marshallOptions: { removeUndefinedValues: true } });
  }
  async get(resource, entity) {
    const Key = keyFor(resource, entity);
    const r = await this.client.send(new GetCommand2({ TableName: this.tableName, Key, ConsistentRead: true }));
    return r.Item ?? null;
  }
  async query(pk, { index = "GSI1", sortPrefix, limit = 100 } = {}) {
    const result = [];
    let last;
    do {
      const q = { TableName: this.tableName, IndexName: index, KeyConditionExpression: "#p = :p", ExpressionAttributeNames: { "#p": `${index}PK` }, ExpressionAttributeValues: { ":p": pk }, Limit: Math.min(limit - result.length, 100), ExclusiveStartKey: last };
      if (sortPrefix) {
        q.KeyConditionExpression += " AND begins_with(#s,:s)";
        q.ExpressionAttributeNames["#s"] = `${index}SK`;
        q.ExpressionAttributeValues[":s"] = sortPrefix;
      }
      const out = await this.client.send(new QueryCommand2(q));
      result.push(...out.Items || []);
      last = out.LastEvaluatedKey;
    } while (last && result.length < limit);
    return { items: result, nextPage: !!last };
  }
  async queryBase(pk, limit = 200) {
    const rows = [];
    let last;
    do {
      const out = await this.client.send(new QueryCommand2({ TableName: this.tableName, KeyConditionExpression: "#p=:p", ExpressionAttributeNames: { "#p": "PK" }, ExpressionAttributeValues: { ":p": pk }, Limit: Math.min(100, limit - rows.length), ExclusiveStartKey: last, ConsistentRead: true }));
      rows.push(...out.Items || []);
      last = out.LastEvaluatedKey;
    } while (last && rows.length < limit);
    return { items: rows, nextPage: !!last };
  }
  async auditPut({ inst, claims, type, resource, id, details }) {
    const ts = (/* @__PURE__ */ new Date()).toISOString();
    return {
      PK: `AUDIT#${inst}`,
      SK: `AT#${ts}#${newId("EVT")}`,
      entityType: "AUDIT",
      type,
      resource,
      id,
      details,
      actorSub: claims.sub,
      at: ts
    };
  }
  txPut(item, condition) {
    return { Put: { TableName: this.tableName, Item: item, ...condition ? { ConditionExpression: condition } : {} } };
  }
  async transact(actions) {
    try {
      await this.client.send(new TransactWriteCommand2({ TransactItems: actions }));
    } catch (e) {
      if (e.name === "TransactionCanceledException") throw httpError(409, "Record was changed or already exists. Refresh and try again.");
      throw e;
    }
  }
  async ensureVisible(item, inst) {
    if (!item || !(item.visibleIn || [item.createdIn]).includes(inst)) throw httpError(404, "Record not found in your institution.");
  }
  async list(resource, inst, claims, { studentId } = {}) {
    if (resource === "venues" || resource === "classes") demandViewInstitution(claims, inst);
    else demandInstitution(claims, inst);
    if (resource === "practice") {
      if (!studentId) throw httpError(400, "studentId is required for practice history.");
      const student = await this.get("students", { id: studentId });
      await this.ensureVisible(student, inst);
      const { items: items2, nextPage: nextPage2 } = await this.queryBase(`PRACTICE#${inst}#${studentId}`);
      return { records: items2.map(publicRecord), more: nextPage2 };
    }
    const partition = resource === "families" ? "DIRECTORY#FAMILY" : resource === "students" ? "DIRECTORY#STUDENT" : resource === "venues" ? "DIRECTORY#VENUE" : `INST#${inst}#${resource === "classes" ? "CLASS" : "ENROLMENT"}`;
    const { items, nextPage } = await this.query(partition, { limit: 300 });
    const filtered = resource === "families" || resource === "students" ? items.filter((x) => (x.visibleIn || [x.createdIn]).includes(inst)) : items;
    return { records: filtered.map(publicRecord), more: nextPage };
  }
  async identitySearch(claims, q) {
    demandAnyAdmin(claims);
    const search = clean(q).toLocaleLowerCase("en-GB");
    if (search.length < 3 || search.length > 100) throw httpError(400, "Enter at least three characters of a name.");
    const families = await this.query("DIRECTORY#FAMILY", { sortPrefix: `NAME#${search}`, limit: 20 });
    const students = await this.query("DIRECTORY#STUDENT", { sortPrefix: `NAME#${search}`, limit: 20 });
    return {
      families: families.items.map((r) => ({ id: r.id, parentName: r.parentName, phoneLast4: r.phone?.slice(-4) || "" })),
      students: students.items.map((r) => ({ id: r.id, name: r.name, familyId: r.familyId || null })),
      more: families.nextPage || students.nextPage
    };
  }
  async linkForInstitution(item, inst) {
    if ((item.visibleIn || []).includes(inst)) return null;
    const next = { ...item, visibleIn: [.../* @__PURE__ */ new Set([...item.visibleIn || [item.createdIn], inst])], version: item.version + 1, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    return { Put: { TableName: this.tableName, Item: next, ConditionExpression: "#v=:v", ExpressionAttributeNames: { "#v": "version" }, ExpressionAttributeValues: { ":v": item.version } } };
  }
  async create(resource, input, inst, claims) {
    demandInstitution(claims, inst);
    const d = validate(resource, input);
    if (["classes", "enrolments", "practice"].includes(resource) && d.institution !== inst) throw httpError(403, "Cannot write records for another institution.");
    if (["families", "students"].includes(resource) && d.createdIn !== inst) throw httpError(403, "Registration institution mismatch.");
    if (resource === "students" && d.familyId) {
      const family2 = await this.get("families", { id: d.familyId });
      if (!family2) throw httpError(404, "Parent family record not found.");
    }
    let student, classItem, family;
    if (resource === "enrolments") {
      student = await this.get("students", { id: d.studentId });
      classItem = await this.get("classes", { id: d.classId });
      if (!student || !classItem || classItem.archived || classItem.institution !== inst) throw httpError(400, "Student/class combination is invalid.");
      if (student.familyId) family = await this.get("families", { id: student.familyId });
      const exists = await this.query(`CLASS#${d.classId}`, { index: "GSI2", sortPrefix: `STUDENT#${d.studentId}#`, limit: 100 });
      if (exists.items.some((x) => !x.archived && !(x.endDate && x.endDate < d.startDate) && !(d.endDate && d.endDate < x.startDate))) throw httpError(409, "Student already has an overlapping enrolment in this class.");
    }
    if (resource === "classes" && d.mode === "In Person") {
      if (!await this.get("venues", { id: d.venueId })) throw httpError(400, "Venue must exist in the shared venue directory.");
    }
    if (resource === "practice") {
      student = await this.get("students", { id: d.studentId });
      await this.ensureVisible(student, inst);
      const entries = await this.query(`INST#${inst}#ENROLMENT`, { sortPrefix: `STUDENT#${d.studentId}#`, limit: 150 });
      if (!entries.items.some((e) => e.startDate <= d.date && (!e.endDate || e.endDate >= d.date))) throw httpError(409, "The student was not enrolled on the practice date.");
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const newItem = { ...d, id: resource === "practice" ? `PRACTICE-${inst}-${d.studentId}-${d.date}` : newId(resource.toUpperCase()), entityType: resource.toUpperCase(), createdAt: now, updatedAt: now, version: 1, archived: false, ...resource === "families" || resource === "students" ? { visibleIn: [inst] } : {} };
    if (resource === "practice") {
      newItem.source = "Administrator Recorded";
      newItem.status = "Active";
    }
    Object.assign(newItem, keyFor(resource, newItem), directoryFor(resource, newItem));
    const audit = await this.auditPut({ inst, claims, type: "CREATE", resource, id: newItem.id, details: {} });
    const actions = [this.txPut(newItem, "attribute_not_exists(PK)"), this.txPut(audit)];
    if (resource === "enrolments") {
      for (const row of [student, family].filter(Boolean)) {
        const update = await this.linkForInstitution(row, inst);
        if (update) actions.push(update);
      }
    }
    await this.transact(actions);
    return publicRecord(newItem);
  }
  async patch(resource, id, input, inst, claims) {
    demandInstitution(claims, inst);
    if (resource === "venues") {
      return await this.patchVenue(id, input, inst, claims);
    }
    if (resource === "practice") throw httpError(400, "Use the practice correction route with a date and student ID.");
    const current = await this.get(resource, { id });
    if (!current) throw httpError(404, "Record not found.");
    if (resource === "families" || resource === "students") await this.ensureVisible(current, inst);
    else if (current.institution !== inst) throw httpError(404, "Record not found in this institution.");
    if (!input || typeof input !== "object" || Array.isArray(input)) throw httpError(400, "Expected changes with expectedVersion.");
    const expectedVersion = input.expectedVersion;
    if (!Number.isInteger(expectedVersion) || expectedVersion !== current.version) throw httpError(409, "This record has changed. Refresh before editing.");
    const { expectedVersion: _discard, ...updates } = input;
    if (["families", "students"].includes(resource) && updates.createdIn && updates.createdIn !== current.createdIn) throw httpError(400, "Registration institution is immutable.");
    if (["classes", "enrolments"].includes(resource) && updates.institution && updates.institution !== current.institution) throw httpError(400, "Institution is immutable.");
    if (resource === "enrolments" && (updates.studentId && updates.studentId !== current.studentId || updates.classId && updates.classId !== current.classId)) throw httpError(400, "Student and class cannot be reassigned inside an enrolment. Create a new enrolment.");
    if (resource === "students" && updates.familyId !== void 0 && updates.familyId !== current.familyId) throw httpError(400, "Changing a Family ID requires a separate verified identity-linking workflow.");
    if (resource === "classes" && updates.venueId && updates.venueId !== current.venueId) {
      if (!await this.get("venues", { id: updates.venueId })) throw httpError(400, "Requested venue does not exist.");
    }
    const merged = validate(resource, Object.fromEntries(ALLOWED_FIELDS[resource].map((f) => [f, f in updates ? updates[f] : current[f]])));
    const next = { ...current, ...merged, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), version: current.version + 1 };
    Object.assign(next, directoryFor(resource, next));
    if (resource === "students" && !next.phone) {
      delete next.GSI2PK;
      delete next.GSI2SK;
    }
    const changed = ALLOWED_FIELDS[resource].filter((k) => JSON.stringify(current[k]) !== JSON.stringify(next[k]));
    const audit = await this.auditPut({ inst, claims, type: "UPDATE", resource, id, details: { changed, previous: Object.fromEntries(changed.map((k) => [k, current[k]])) } });
    await this.transact([{ Put: { TableName: this.tableName, Item: next, ConditionExpression: "#version = :v", ExpressionAttributeNames: { "#version": "version" }, ExpressionAttributeValues: { ":v": expectedVersion } } }, this.txPut(audit)]);
    return publicRecord(next);
  }
  /** Central venue edit. Only the VENUE item plus audit are written; calendar rows stay unchanged. */
  async patchVenue(id, input, inst, claims) {
    if (!/^[-a-zA-Z0-9]{4,100}$/.test(id)) throw httpError(400, "Invalid venue ID.");
    if (!input || typeof input !== "object" || Array.isArray(input)) throw httpError(400, "Expected venue changes with expectedVersion.");
    const expectedVersion = input.expectedVersion;
    if (!Number.isInteger(expectedVersion) || expectedVersion < 1) throw httpError(400, "expectedVersion must be a positive integer.");
    const { expectedVersion: _discard, ...rawUpdates } = input;
    const updates = fieldsOnly(rawUpdates, ALLOWED_FIELDS.venues);
    if (!Object.keys(updates).length) throw httpError(400, "No venue changes supplied.");
    const current = await this.get("venues", { id });
    if (!current) throw httpError(404, "Venue not found.");
    if (current.version !== expectedVersion) throw httpError(409, "This venue was changed elsewhere. Refresh and try again.");
    const merged = validate("venues", Object.fromEntries(ALLOWED_FIELDS.venues.map((f) => [f, f in updates ? updates[f] : current[f]])));
    const changed = ALLOWED_FIELDS.venues.filter((f) => JSON.stringify(current[f] ?? "") !== JSON.stringify(merged[f] ?? ""));
    if (!changed.length) return publicRecord(current);
    const next = { ...current, ...merged, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), version: current.version + 1 };
    Object.assign(next, directoryFor("venues", next));
    const audit = await this.auditPut({ inst, claims, type: "UPDATE", resource: "venues", id, details: { changed, previous: Object.fromEntries(changed.map((f) => [f, current[f] ?? ""])) } });
    await this.transact([{ Put: { TableName: this.tableName, Item: next, ConditionExpression: "attribute_exists(PK) AND #v = :expected", ExpressionAttributeNames: { "#v": "version" }, ExpressionAttributeValues: { ":expected": expectedVersion } } }, this.txPut(audit)]);
    return publicRecord(next);
  }
  async correctPractice({ studentId, date: date2, institution, expectedVersion, ...changes }, claims) {
    demandInstitution(claims, institution);
    const current = await this.get("practice", { studentId, date: date2, institution });
    if (!current) throw httpError(404, "Practice entry not found.");
    if (!Number.isInteger(expectedVersion) || expectedVersion !== current.version) throw httpError(409, "This practice entry was modified; refresh first.");
    if (current.status === "Voided") throw httpError(409, "Voided entries cannot be edited.");
    const d = validate("practice", { institution, studentId, date: date2, didPractice: changes.didPractice ?? current.didPractice, minutes: changes.minutes ?? current.minutes, comments: changes.comments ?? current.comments, reason: changes.reason });
    const next = { ...current, ...d, version: current.version + 1, source: "Administrator Corrected", updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    const audit = await this.auditPut({ inst: institution, claims, type: "PRACTICE_CORRECTION", resource: "practice", id: current.id, details: { reason: d.reason, previous: { didPractice: current.didPractice, minutes: current.minutes, comments: current.comments } } });
    await this.transact([{ Put: { TableName: this.tableName, Item: next, ConditionExpression: "#v = :v", ExpressionAttributeNames: { "#v": "version" }, ExpressionAttributeValues: { ":v": expectedVersion } } }, this.txPut(audit)]);
    return publicRecord(next);
  }
  async voidPractice({ institution, studentId, date: date2, reason, expectedVersion }, claims) {
    demandInstitution(claims, institution);
    if (!clean(reason)) throw httpError(400, "A void reason is required.");
    const current = await this.get("practice", { institution, studentId, date: date2 });
    if (!current) throw httpError(404, "Practice entry not found.");
    if (!Number.isInteger(expectedVersion) || expectedVersion !== current.version) throw httpError(409, "This practice entry was modified; refresh first.");
    if (current.status === "Voided") throw httpError(409, "Already voided.");
    const next = { ...current, status: "Voided", version: current.version + 1, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    const audit = await this.auditPut({ inst: institution, claims, type: "PRACTICE_VOID", resource: "practice", id: current.id, details: { reason: clean(reason) } });
    await this.transact([{ Put: { TableName: this.tableName, Item: next, ConditionExpression: "#v = :v", ExpressionAttributeNames: { "#v": "version" }, ExpressionAttributeValues: { ":v": expectedVersion } } }, this.txPut(audit)]);
    return publicRecord(next);
  }
};

// src/apiRoute.ts
function apiRouteParts(event) {
  const proxy = event.pathParameters?.proxy;
  if (typeof proxy === "string") return proxy.split("/").filter(Boolean);
  const raw = event.rawPath ?? event.path ?? "";
  const stage = event.requestContext?.stage;
  const withoutStage = stage && stage !== "$default" && raw.startsWith(`/${stage}/`) ? raw.slice(stage.length + 1) : raw;
  const prefix = withoutStage.match(/^\/api(?:\/|$)/) ?? withoutStage.match(/^\/[^/]+\/api(?:\/|$)/);
  if (!prefix) return [];
  return withoutStage.slice(prefix[0].length).split("/").filter(Boolean);
}

// src/calendarSync.ts
import { SSMClient, GetParameterCommand } from "@aws-sdk/client-ssm";
import { DynamoDBClient as DynamoDBClient3 } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient as DynamoDBDocumentClient3, PutCommand, QueryCommand as QueryCommand3 } from "@aws-sdk/lib-dynamodb";

// src/calendarModel.ts
var MIDDLESBROUGH_PARTITION = "CALENDAR#raaga#middlesbrough";

// src/calendarSync.ts
var ssm = new SSMClient({});
var db2 = DynamoDBDocumentClient3.from(new DynamoDBClient3({}), { marshallOptions: { removeUndefinedValues: true } });
var table2 = () => {
  const name = process.env.SADHANA_TABLE_NAME;
  if (!name) throw new Error("DynamoDB is not configured");
  return name;
};
async function storedSessions() {
  let next;
  const items = [];
  do {
    const response = await db2.send(new QueryCommand3({ TableName: table2(), KeyConditionExpression: "PK = :pk", ExpressionAttributeValues: { ":pk": MIDDLESBROUGH_PARTITION }, ExclusiveStartKey: next, Limit: 200 }));
    for (const x of response.Items ?? []) items.push(x);
    next = response.LastEvaluatedKey;
    if (items.length > 1500) throw new Error("Too many stored Middlesbrough events; refusing unbounded scan");
  } while (next);
  return items;
}
async function listMiddlesbrough() {
  const events = await storedSessions();
  const projected = events.map((x) => ({
    id: x.id,
    summary: x.summary,
    start: x.start,
    end: x.end,
    location: x.location,
    status: x.status,
    institution: "raaga",
    calendar: "middlesbrough",
    source: "google"
  }));
  return { events: projected.sort((a, b) => a.start.localeCompare(b.start)), source: "DynamoDB mirror \xB7 Middlesbrough Google Calendar" };
}

// src/eventManagement.ts
import { randomUUID as randomUUID3 } from "node:crypto";
import { DynamoDBClient as DynamoDBClient4 } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient as DynamoDBDocumentClient4, GetCommand as GetCommand3, PutCommand as PutCommand2, QueryCommand as QueryCommand4, TransactWriteCommand as TransactWriteCommand3 } from "@aws-sdk/lib-dynamodb";
var db3 = DynamoDBDocumentClient4.from(new DynamoDBClient4({}), { marshallOptions: { removeUndefinedValues: true } });
var table3 = () => {
  if (!process.env.SADHANA_TABLE_NAME) throw Error("Missing Sadhana table name");
  return process.env.SADHANA_TABLE_NAME;
};
var date = /^\d{4}-\d{2}-\d{2}$/;
var time = /^([01]\d|2[0-3]):[0-5]\d$/;
async function teacherFor(sub, inst) {
  const matches = [];
  let next;
  do {
    const res = await db3.send(new QueryCommand4({ TableName: table3(), KeyConditionExpression: "PK=:pk", ExpressionAttributeValues: { ":pk": "TEACHER_REGISTRY" }, ConsistentRead: true, ExclusiveStartKey: next, Limit: 250 }));
    matches.push(...(res.Items || []).filter((t) => t.active && t.cognitoSub === sub && t.institutions?.includes(inst)));
    next = res.LastEvaluatedKey;
    if (matches.length > 1) throw httpError(409, "Multiple teacher profiles are linked to this account.");
  } while (next);
  return matches[0];
}
async function actor(inst, claims) {
  if (!viewableInstitutions(claims).includes(inst)) throw httpError(403, "Institution access required.");
  const admin = permittedInstitutions(claims).includes(inst);
  const self = admin ? null : await teacherFor(String(claims.sub), inst);
  if (!admin && !self) throw httpError(403, "Your account must be linked to an active teacher profile to manage events.");
  return { admin, self };
}
async function verifyAssignee(inst, id) {
  const res = await db3.send(new GetCommand3({ TableName: table3(), Key: { PK: "TEACHER_REGISTRY", SK: `TEACHER#${id}` }, ConsistentRead: true }));
  if (!res.Item?.active || !res.Item.institutions?.includes(inst)) throw httpError(400, "Choose an active teacher in this academy.");
  return res.Item;
}
function data(input, inst) {
  const permitted = ["name", "programme", "eventKind", "date", "startTime", "endTime", "mode", "location", "venueId", "teacherId"];
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).some((k) => !permitted.includes(k))) throw httpError(400, "Invalid event fields.");
  if (input.eventKind !== "class" && input.eventKind !== "event") throw httpError(400, "Choose an event type.");
  if (typeof input.name !== "string" || !input.name.trim() || input.name.length > 150) throw httpError(400, "Enter an event name.");
  if (typeof input.date !== "string" || !date.test(input.date) || Number.isNaN(Date.parse(input.date + "T12:00:00Z"))) throw httpError(400, "Choose a valid event date.");
  if (typeof input.startTime !== "string" || typeof input.endTime !== "string" || !time.test(input.startTime) || !time.test(input.endTime) || input.startTime >= input.endTime) throw httpError(400, "Choose a valid same-day time range.");
  for (const field of ["programme", "mode", "location"]) if (typeof input[field] !== "string" || input[field].length > 300) throw httpError(400, `Invalid ${field}.`);
  if (typeof input.venueId !== "string" || input.venueId.length > 120) throw httpError(400, "Choose a venue.");
  if (input.eventKind === "event") {
    if (input.programme !== "Event" || input.mode !== "Event" || input.location !== "" || input.venueId !== "" || input.teacherId !== void 0)
      throw httpError(400, "Events must use the Event programme without a teacher, delivery or venue.");
  } else {
    const allowed = input.eventKind === "class" ? inst === "raaga" ? ["Singing"] : ["Vedam", "Vedanta"] : [];
    if (!allowed.includes(String(input.programme))) throw httpError(400, "Choose a programme permitted for this academy.");
    if (input.mode !== "Online" && input.mode !== "In person") throw httpError(400, "Choose a delivery mode.");
  }
  if (input.eventKind === "class" && input.mode === "Online" && (input.location !== "Online" || input.venueId !== "")) throw httpError(400, "Online events must use Online as the venue.");
  if (input.eventKind === "class" && input.mode !== "Online" && !input.venueId) throw httpError(400, "Choose an in-person venue.");
  if (input.teacherId !== void 0 && (typeof input.teacherId !== "string" || !/^TEACHER-[0-9a-f-]{36}$/i.test(input.teacherId))) throw httpError(400, "Choose a registered teacher.");
  return input;
}
async function listManagedEvents(inst, claims) {
  const { admin, self } = await actor(inst, claims);
  const rows = [];
  let next;
  do {
    const result = await db3.send(new QueryCommand4({ TableName: table3(), KeyConditionExpression: "PK=:pk", ExpressionAttributeValues: { ":pk": schedulePK(inst) }, ExclusiveStartKey: next, Limit: 250 }));
    rows.push(...(result.Items || []).filter((x) => x.recordType === "special-event" && x.managedEvent === true));
    next = result.LastEvaluatedKey;
    if (rows.length > 3e3) throw httpError(413, "Too many events.");
  } while (next);
  return { records: rows.filter((x) => admin || x.teacherId === self.id).map(({ PK, SK, entityType, ...r }) => r) };
}
async function saveManagedEvent(inst, claims, input, id) {
  const { admin, self } = await actor(inst, claims);
  const expectedVersion = input.expectedVersion;
  const { expectedVersion: _ignored, ...raw } = input;
  const fields = data(raw, inst);
  if (admin && fields.eventKind === "class" && !fields.teacherId) throw httpError(400, "Choose a registered teacher.");
  const teacherId = fields.eventKind === "event" ? admin ? "" : self.id : admin ? String(fields.teacherId) : self.id;
  if (!admin && fields.teacherId !== void 0 && fields.teacherId !== self.id) throw httpError(403, "Teachers can assign events only to themselves.");
  const teacher = teacherId ? await verifyAssignee(inst, teacherId) : null;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  let old;
  if (id) {
    const res = await db3.send(new GetCommand3({ TableName: table3(), Key: { PK: schedulePK(inst), SK: scheduleSK(id) }, ConsistentRead: true }));
    old = res.Item;
    if (!old || old.managedEvent !== true) throw httpError(404, "Managed event not found.");
    if (old.sharedEvent) throw httpError(409, "Use shared event management for this event.");
    if (!admin && old.teacherId !== self.id) throw httpError(403, "You can edit only your own events.");
    if (old.version !== expectedVersion) throw httpError(409, "Event changed; refresh before editing.");
  } else if (expectedVersion !== void 0) throw httpError(400, "Unexpected event version.");
  const record = {
    id: id || `EVT-${randomUUID3()}`,
    institution: inst,
    recordType: "special-event",
    managedEvent: true,
    name: String(fields.name).trim(),
    programme: fields.programme,
    eventKind: fields.eventKind,
    teacherId,
    teacher: teacher?.displayName || "",
    date: fields.date,
    endDate: fields.date,
    startTime: fields.startTime,
    endTime: fields.endTime,
    allDay: false,
    mode: fields.mode,
    location: fields.location,
    venueId: fields.venueId,
    timezone: "Europe/London",
    status: "confirmed",
    version: (old?.version || 0) + 1,
    createdAt: old?.createdAt || now,
    createdBy: old?.createdBy || String(claims.sub),
    updatedAt: now,
    updatedBy: String(claims.sub)
  };
  const condition = id ? "#v=:old" : "attribute_not_exists(PK)";
  try {
    await db3.send(new PutCommand2({ TableName: table3(), Item: { PK: schedulePK(inst), SK: scheduleSK(record.id), entityType: "schedule", ...record }, ConditionExpression: condition, ...id ? { ExpressionAttributeNames: { "#v": "version" }, ExpressionAttributeValues: { ":old": old.version } } : {} }));
  } catch (e) {
    if (e.name === "ConditionalCheckFailedException") throw httpError(409, "Event changed; refresh.");
    throw e;
  }
  return { record };
}
async function cancelManagedEvent(inst, claims, id, expectedVersion) {
  const { admin, self } = await actor(inst, claims);
  const res = await db3.send(new GetCommand3({ TableName: table3(), Key: { PK: schedulePK(inst), SK: scheduleSK(id) }, ConsistentRead: true }));
  const old = res.Item;
  if (!old || old.managedEvent !== true) throw httpError(404, "Managed event not found.");
  if (old.sharedEvent) throw httpError(409, "Use shared event management for this event.");
  if (!admin && old.teacherId !== self.id) throw httpError(403, "You can cancel only your own events.");
  if (old.version !== expectedVersion) throw httpError(409, "Event changed; refresh.");
  const next = { ...old, status: "cancelled", version: old.version + 1, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), updatedBy: String(claims.sub) };
  try {
    await db3.send(new PutCommand2({ TableName: table3(), Item: next, ConditionExpression: "#v=:old", ExpressionAttributeNames: { "#v": "version" }, ExpressionAttributeValues: { ":old": old.version } }));
  } catch (e) {
    if (e.name === "ConditionalCheckFailedException") throw httpError(409, "Event changed; refresh.");
    throw e;
  }
  return { record: next };
}
function requireBothAdmins(claims) {
  const allowed = permittedInstitutions(claims);
  if (!allowed.includes("raaga") || !allowed.includes("sruti")) throw httpError(403, "Shared events require administrator access to both academies.");
}
async function getSharedPair(id) {
  const [raaga, sruti] = await Promise.all(["raaga", "sruti"].map(async (inst) => {
    const response = await db3.send(new GetCommand3({ TableName: table3(), Key: { PK: schedulePK(inst), SK: scheduleSK(id) }, ConsistentRead: true }));
    return response.Item;
  }));
  if (!raaga || !sruti || !raaga.sharedEvent || !sruti.sharedEvent || raaga.id !== sruti.id)
    throw httpError(409, "The shared calendar event pair is incomplete; no changes were made.");
  if (raaga.version !== sruti.version) throw httpError(409, "Shared event versions differ; no changes were made.");
  return [raaga, sruti];
}
async function saveSharedEvent(claims, input, id) {
  requireBothAdmins(claims);
  const { expectedVersion, ...raw } = input;
  const fields = data(raw, "raaga");
  if (fields.eventKind !== "event") throw httpError(400, "Only Events may be shared across both academies.");
  const old = id ? await getSharedPair(id) : null;
  if (id && (!Number.isInteger(expectedVersion) || old[0].version !== expectedVersion)) throw httpError(409, "Shared event changed; refresh before editing.");
  if (!id && expectedVersion !== void 0) throw httpError(400, "Unexpected version.");
  const eventId = id || `EVT-${randomUUID3()}`;
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const nextVersion = id ? old[0].version + 1 : 1;
  const records = ["raaga", "sruti"].map((inst, index) => ({
    PK: schedulePK(inst),
    SK: scheduleSK(eventId),
    entityType: "schedule",
    id: eventId,
    institution: inst,
    recordType: "special-event",
    managedEvent: true,
    sharedEvent: true,
    name: String(fields.name).trim(),
    programme: "Event",
    eventKind: "event",
    teacherId: "",
    teacher: "",
    date: fields.date,
    endDate: fields.date,
    startTime: fields.startTime,
    endTime: fields.endTime,
    allDay: false,
    mode: "Event",
    location: "",
    venueId: "",
    timezone: "Europe/London",
    status: old?.[index].status || "confirmed",
    version: nextVersion,
    createdAt: old?.[index].createdAt || now,
    createdBy: old?.[index].createdBy || String(claims.sub),
    updatedAt: now,
    updatedBy: String(claims.sub)
  }));
  try {
    await db3.send(new TransactWriteCommand3({ TransactItems: records.map((record) => ({ Put: {
      TableName: table3(),
      Item: record,
      ConditionExpression: id ? "#version = :version" : "attribute_not_exists(PK)",
      ...id ? { ExpressionAttributeNames: { "#version": "version" }, ExpressionAttributeValues: { ":version": Number(expectedVersion) } } : {}
    } })) }));
  } catch (e) {
    if (e.name === "TransactionCanceledException") throw httpError(409, "Shared event conflict; refresh before retrying.");
    throw e;
  }
  return { record: records[0], records };
}
async function cancelSharedEvent(claims, id, expectedVersion) {
  requireBothAdmins(claims);
  const old = await getSharedPair(id);
  if (!Number.isInteger(expectedVersion) || old[0].version !== expectedVersion) throw httpError(409, "Shared event changed; refresh.");
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const updated = old.map((item) => ({ ...item, status: "cancelled", version: item.version + 1, updatedAt: now, updatedBy: String(claims.sub) }));
  try {
    await db3.send(new TransactWriteCommand3({ TransactItems: updated.map((item) => ({ Put: {
      TableName: table3(),
      Item: item,
      ConditionExpression: "#version = :version",
      ExpressionAttributeNames: { "#version": "version" },
      ExpressionAttributeValues: { ":version": expectedVersion }
    } })) }));
  } catch (e) {
    if (e.name === "TransactionCanceledException") throw httpError(409, "Shared event conflict; refresh.");
    throw e;
  }
  return { record: updated[0], records: updated };
}

// src/scheduleStore.ts
import { randomUUID as randomUUID4 } from "node:crypto";
import { DynamoDBClient as DynamoDBClient5 } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient as DynamoDBDocumentClient5, GetCommand as GetCommand4, PutCommand as PutCommand3, QueryCommand as QueryCommand5, TransactWriteCommand as TransactWriteCommand4, DeleteCommand } from "@aws-sdk/lib-dynamodb";

// src/scheduleSeries.ts
var SERIES_FIELDS = ["teacher", "teacherId", "startTime", "endTime", "name", "programme", "mode", "location", "status"];
var seriesPK = (inst) => `SCHEDULE_SERIES#${inst}`;
var seriesSK = (classId, date2) => `CLASS#${classId}#FROM#${date2}`;
function todayLondon(now = /* @__PURE__ */ new Date()) {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/London", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(now);
  const fields = Object.fromEntries(parts.map((x) => [x.type, x.value]));
  return `${fields.year}-${fields.month}-${fields.day}`;
}
function parseSeriesChange(input, master, fromToday = todayLondon()) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw httpError(400, "Expected a series change object.");
  const allowed = ["effectiveFrom", "effectiveUntil", "expectedVersion", "changes"];
  if (Object.keys(input).some((k) => !allowed.includes(k))) throw httpError(400, "Unsupported series change field.");
  if (!Number.isInteger(input.expectedVersion) || input.expectedVersion !== master.version) throw httpError(409, "The class has changed. Refresh before editing its series.");
  const effectiveFrom = input.effectiveFrom;
  if (typeof effectiveFrom !== "string" || !isoDate(effectiveFrom) || effectiveFrom < fromToday) throw httpError(400, "Choose today or a future UK date for series changes.");
  const effectiveUntil = input.effectiveUntil;
  if (effectiveUntil !== void 0 && (typeof effectiveUntil !== "string" || !isoDate(effectiveUntil) || effectiveUntil < effectiveFrom)) throw httpError(400, "End date must be a valid UK date on or after the start date.");
  const raw = input.changes;
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw httpError(400, "Choose at least one class change.");
  const payload = raw;
  const keys = Object.keys(payload);
  if (!keys.length || keys.some((k) => !SERIES_FIELDS.includes(k))) throw httpError(400, "Unsupported series change field.");
  const changes = {};
  for (const key of keys) {
    if (typeof payload[key] !== "string") throw httpError(400, `${key} must be text.`);
    changes[key] = payload[key].trim();
  }
  if ("teacher" in changes && !changes.teacher) throw httpError(400, "Teacher cannot be blank.");
  if ("name" in changes && !changes.name) throw httpError(400, "Class name cannot be blank.");
  if ("programme" in changes && !changes.programme) throw httpError(400, "Programme cannot be blank.");
  if ("mode" in changes && !changes.mode) throw httpError(400, "Delivery cannot be blank.");
  if ("status" in changes && !["confirmed", "tentative", "cancelled"].includes(changes.status || "")) throw httpError(400, "Invalid class status.");
  if ("teacherId" in changes && (!changes.teacher || !/^TEACHER-[0-9a-f-]{36}$/i.test(changes.teacherId || ""))) throw httpError(400, "Teacher ID requires a matching teacher name.");
  return { effectiveFrom, effectiveUntil, changes, expectedVersion: master.version };
}
function projectSeriesRecord(record, rules, today = todayLondon()) {
  const isMaster = record.recordType === "class";
  if (!isMaster && record.recordType !== "class-session") return record;
  const classId = isMaster ? record.id : record.classId;
  const date2 = isMaster ? today : record.date;
  if (!classId || !date2) return record;
  const patches = rules.filter((x) => x.institution === record.institution && x.classId === classId && x.effectiveFrom <= date2 && (!x.effectiveUntil || date2 <= x.effectiveUntil)).sort((a, b) => a.effectiveFrom.localeCompare(b.effectiveFrom));
  if (!patches.length) return record;
  const exceptions = new Set(record.sessionOverrideFields || []);
  const values = {};
  for (const rule of patches) Object.assign(values, rule.changes);
  const applied = { ...record };
  for (const key of SERIES_FIELDS) {
    if (values[key] === void 0) continue;
    if (!isMaster && (exceptions.has(key) || key === "teacherId" && exceptions.has("teacher"))) continue;
    applied[key] = values[key];
  }
  const lastTeacherRule = patches.filter((x) => x.changes.teacher !== void 0).at(-1);
  if (lastTeacherRule && !lastTeacherRule.changes.teacherId) {
    if (isMaster || !exceptions.has("teacher")) delete applied.teacherId;
  }
  if (!isMaster && exceptions.has("teacher") && !record.teacherId) delete applied.teacherId;
  return validateScheduleRecord(applied);
}
function validateSeriesCandidate(master, existingRules, newRule) {
  const all = [...existingRules, newRule];
  const dates = /* @__PURE__ */ new Set([newRule.effectiveFrom]);
  const nextDay = (day2) => {
    const date2 = /* @__PURE__ */ new Date(`${day2}T12:00:00Z`);
    date2.setUTCDate(date2.getUTCDate() + 1);
    return date2.toISOString().slice(0, 10);
  };
  for (const rule of all.filter((x) => x.classId === master.id)) {
    if (rule.effectiveFrom >= newRule.effectiveFrom) dates.add(rule.effectiveFrom);
    if (rule.effectiveUntil) {
      const after = nextDay(rule.effectiveUntil);
      if (after >= newRule.effectiveFrom) dates.add(after);
    }
  }
  for (const day2 of dates) validateScheduleRecord(projectSeriesRecord(master, all, day2));
}

// src/teacherNameMatch.ts
function normalizedTeacherName(value) {
  return String(value || "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/^(?:dr|mr|mrs|ms|miss|prof|professor)\.?\s+/, "").replace(/[^a-z0-9]/g, "");
}
function matchesTeacherName(name, teacher) {
  const target = normalizedTeacherName(name);
  return !!target && [teacher.displayName, ...teacher.aliases || []].some((x) => normalizedTeacherName(x) === target);
}
function suggestedTeacherIds(name, teachers) {
  return teachers.filter((t) => t.active && matchesTeacherName(name, t)).map((t) => t.id);
}

// src/calendarImpact.ts
function calculateSeriesImpact(records, rules, candidate) {
  const relevant = records.filter((r) => r.recordType === "class-session" && r.classId === candidate.classId && r.institution === candidate.institution && !!r.date && r.date >= candidate.effectiveFrom && (!candidate.effectiveUntil || r.date <= candidate.effectiveUntil));
  const changed = [];
  const protectedSessions = [];
  for (const r of relevant) {
    const before = projectSeriesRecord(r, rules);
    const after = projectSeriesRecord(r, [...rules, candidate]);
    const differences = Object.keys(candidate.changes).filter((k) => before[k] !== after[k]);
    if (differences.length) changed.push(r.id);
    else if (Object.keys(candidate.changes).some((k) => r.sessionOverrideFields?.includes(k))) protectedSessions.push(r.id);
  }
  const conflicts = rules.filter((r) => r.classId === candidate.classId && r.institution === candidate.institution && r.effectiveFrom >= candidate.effectiveFrom && (!candidate.effectiveUntil || r.effectiveFrom <= candidate.effectiveUntil) && Object.keys(candidate.changes).some((k) => r.changes[k] !== void 0)).map((r) => ({ effectiveFrom: r.effectiveFrom, effectiveUntil: r.effectiveUntil || null, changes: r.changes }));
  return { totalSessions: relevant.length, changedCount: changed.length, changedSessionIds: changed, protectedCount: protectedSessions.length, protectedSessionIds: protectedSessions, overlappingRules: conflicts };
}

// src/scheduleStore.ts
var db4 = DynamoDBDocumentClient5.from(new DynamoDBClient5({}), { marshallOptions: { removeUndefinedValues: true } });
var table4 = () => {
  if (!process.env.SADHANA_TABLE_NAME) throw Error("Missing DynamoDB table name");
  return process.env.SADHANA_TABLE_NAME;
};
function canAccess(claims, inst, writing = false) {
  if (inst === "shared") {
    demandAnyStaff(claims);
    if (writing && permittedInstitutions(claims).length !== 2) throw httpError(403, "Shared events require a dual-academy administrator.");
  } else if (writing) demandInstitution(claims, inst);
  else demandViewInstitution(claims, inst);
}
function toPublic(item) {
  const { PK, SK, entityType, ...fields } = item;
  return fields;
}
async function listSeriesRules(inst) {
  const rules = [];
  let next;
  do {
    const response = await db4.send(new QueryCommand5({ TableName: table4(), KeyConditionExpression: "PK=:pk", ExpressionAttributeValues: { ":pk": seriesPK(inst) }, ExclusiveStartKey: next, Limit: 250 }));
    rules.push(...(response.Items || []).map((x) => x));
    next = response.LastEvaluatedKey;
    if (rules.length > 2e3) throw httpError(413, "Too many historical class changes.");
  } while (next);
  return rules;
}
async function listSchedule(inst, claims) {
  canAccess(claims, inst);
  const items = [];
  let next;
  do {
    const response = await db4.send(new QueryCommand5({ TableName: table4(), KeyConditionExpression: "PK=:pk", ExpressionAttributeValues: { ":pk": schedulePK(inst) }, ExclusiveStartKey: next, Limit: 250 }));
    items.push(...(response.Items || []).map((x) => toPublic(x)));
    next = response.LastEvaluatedKey;
    if (items.length > 3e3) throw httpError(413, "Too many schedule records; narrow the API scope.");
  } while (next);
  if (inst === "shared") return { records: items.filter((r) => r.recordType === "holiday" || r.recordType === "special-event"), more: false, source: "Sadhana DynamoDB" };
  const rules = await listSeriesRules(inst);
  return { records: items.map((r) => projectSeriesRecord(r, rules)), more: false, source: "Sadhana DynamoDB" };
}
async function getScheduleRecord(inst, id) {
  if (!/^[-a-zA-Z0-9]{4,90}$/.test(id)) throw httpError(400, "Invalid schedule ID.");
  const value = await db4.send(new GetCommand4({ TableName: table4(), Key: { PK: schedulePK(inst), SK: scheduleSK(id) } }));
  return value.Item ? toPublic(value.Item) : null;
}
async function changeSchedule(inst, id, input, claims) {
  canAccess(claims, inst, true);
  const current = await getScheduleRecord(inst, id);
  if (!current) throw httpError(404, "Schedule entry not found.");
  if (input.expectedVersion !== current.version) throw httpError(409, "This event has changed. Refresh it before editing.");
  const updated = scheduleChanges(current, input);
  if (Object.prototype.hasOwnProperty.call(input, "teacherId")) {
    if (current.recordType !== "class-session") throw httpError(400, "Teacher identity for a master class must be linked separately.");
    if (typeof input.teacher !== "string" || !input.teacher.trim()) throw httpError(400, "Choose a teacher name with its registered identity.");
    const id2 = input.teacherId;
    if (typeof id2 !== "string" || !id2) throw httpError(400, "Choose a registered teacher.");
    const match = await db4.send(new GetCommand4({ TableName: table4(), Key: { PK: "TEACHER_REGISTRY", SK: `TEACHER#${id2}` }, ConsistentRead: true }));
    const teacher = match.Item;
    if (!teacher || !teacher.active || !teacher.institutions?.includes(inst) || !matchesTeacherName(input.teacher, teacher))
      throw httpError(400, "Selected teacher must be active, belong to this institution and match the teacher name.");
  }
  const altered = Object.keys(input).filter((k) => k !== "expectedVersion" && current[k] !== updated[k]);
  const sessionOverrideFields = current.recordType === "class-session" ? [.../* @__PURE__ */ new Set([...current.sessionOverrideFields || [], ...altered])] : current.sessionOverrideFields;
  const next = { ...updated, ...sessionOverrideFields ? { sessionOverrideFields } : {}, version: (current.version || 1) + 1, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
  if (altered.includes("teacher") && !Object.prototype.hasOwnProperty.call(input, "teacherId")) delete next.teacherId;
  try {
    await db4.send(new PutCommand3({ TableName: table4(), Item: { PK: schedulePK(inst), SK: scheduleSK(id), entityType: "schedule", ...next }, ConditionExpression: "#v = :version", ExpressionAttributeNames: { "#v": "version" }, ExpressionAttributeValues: { ":version": current.version } }));
  } catch (e) {
    if (e.name === "ConditionalCheckFailedException") throw httpError(409, "This event has changed. Refresh it before editing.");
    throw e;
  }
  return { record: next };
}
async function createSchedule(inst, body, claims) {
  canAccess(claims, inst, true);
  if (!body || typeof body !== "object" || Array.isArray(body)) throw httpError(400, "Expected an event object.");
  const accepted = /* @__PURE__ */ new Set(["recordType", "name", "programme", "teacher", "mode", "location", "date", "endDate", "startTime", "endTime", "allDay", "status", "classId", "affectsClasses"]);
  const illegal = Object.keys(body).filter((k) => !accepted.has(k));
  if (illegal.length) throw httpError(400, `Unexpected fields: ${illegal.join(", ")}`);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const record = validateScheduleRecord({ ...body, id: `EVT-${randomUUID4()}`, institution: inst, timezone: "Europe/London", version: 1, createdAt: now, updatedAt: now });
  if (record.recordType === "class-session") {
    const master = await getScheduleRecord(inst, record.classId);
    if (master?.recordType !== "class") throw httpError(400, "The session must belong to a master class in the same institution.");
  }
  try {
    await db4.send(new PutCommand3({ TableName: table4(), Item: { PK: schedulePK(inst), SK: scheduleSK(record.id), entityType: "schedule", ...record }, ConditionExpression: "attribute_not_exists(PK)" }));
  } catch (e) {
    if (e.name === "ConditionalCheckFailedException") throw httpError(409, "This event already exists.");
    throw e;
  }
  return { record };
}
async function deleteScheduleSession(inst, id, input, claims) {
  if (inst === "shared") throw httpError(400, "Only academy sessions may be removed here.");
  demandInstitution(claims, inst);
  if (!input || !Number.isInteger(input.expectedVersion)) throw httpError(400, "Expected session version is required.");
  const current = await getScheduleRecord(inst, id);
  if (!current) throw httpError(404, "Session not found.");
  if (current.recordType !== "class-session" && current.recordType !== "special-event") throw httpError(400, "Master classes, holidays and recurring rules cannot be deleted here.");
  if (current.managedEvent || current.sharedEventId) throw httpError(400, "Managed events must use the event management workflow.");
  if (current.version !== input.expectedVersion) throw httpError(409, "This session has changed. Refresh before deleting.");
  try {
    await db4.send(new DeleteCommand({ TableName: table4(), Key: { PK: schedulePK(inst), SK: scheduleSK(id) }, ConditionExpression: "#ver=:expected AND #type=:type", ExpressionAttributeNames: { "#ver": "version", "#type": "recordType" }, ExpressionAttributeValues: { ":expected": current.version, ":type": current.recordType } }));
  } catch (e) {
    if (e.name === "ConditionalCheckFailedException") throw httpError(409, "Session changed. Refresh before deleting.");
    throw e;
  }
  return { deleted: true, id };
}
async function deleteSeriesSessions(inst, id, input, claims, preview) {
  if (inst === "shared") throw httpError(400, "Choose one academy.");
  demandInstitution(claims, inst);
  const master = await getScheduleRecord(inst, id);
  if (!master || master.recordType !== "class") throw httpError(404, "Master class not found.");
  if (!Number.isInteger(input.expectedVersion) || input.expectedVersion !== master.version) throw httpError(409, "Master class changed. Refresh before proceeding.");
  const from = input.effectiveFrom, until = input.effectiveUntil;
  if (typeof from !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(from) || typeof until !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(until) || until < from) throw httpError(400, "Choose a valid start and end date.");
  const all = await listScheduleRaw(inst);
  const matches = all.filter((r) => r.recordType === "class-session" && r.classId === id && r.date >= from && r.date <= until).sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
  if (!matches.length) throw httpError(400, "No stored dated sessions in that range.");
  if (matches.length > 80) throw httpError(413, "More than 80 sessions match. Select a shorter date range.");
  const signature = matches.map((r) => `${r.id}:${r.version}`).join("|");
  if (preview) return { count: matches.length, from, until, dates: matches.map((r) => ({ date: r.date, name: r.name, id: r.id })), signature };
  if (input.confirm !== true || input.signature !== signature) throw httpError(409, "Preview is missing or out of date. Review the dates again.");
  try {
    await db4.send(new TransactWriteCommand4({ TransactItems: [
      { ConditionCheck: { TableName: table4(), Key: { PK: schedulePK(inst), SK: scheduleSK(id) }, ConditionExpression: "#v=:v AND #t=:t", ExpressionAttributeNames: { "#v": "version", "#t": "recordType" }, ExpressionAttributeValues: { ":v": master.version, ":t": "class" } } },
      ...matches.map((r) => ({ Delete: { TableName: table4(), Key: { PK: schedulePK(inst), SK: scheduleSK(r.id) }, ConditionExpression: "#v=:v AND #t=:t AND #class=:class", ExpressionAttributeNames: { "#v": "version", "#t": "recordType", "#class": "classId" }, ExpressionAttributeValues: { ":v": r.version, ":t": "class-session", ":class": id } } }))
    ] }));
  } catch (e) {
    if (e.name === "TransactionCanceledException") throw httpError(409, "One or more sessions changed. Refresh the timetable and preview again.");
    throw e;
  }
  return { deleted: true, count: matches.length };
}
async function deleteMasterClass(inst, id, input, claims, preview) {
  if (inst === "shared") throw httpError(400, "Choose an academy.");
  demandInstitution(claims, inst);
  const master = await getScheduleRecord(inst, id);
  if (!master || master.recordType !== "class") throw httpError(404, "Master class not found.");
  if (input.expectedVersion !== master.version) throw httpError(409, "Master class changed. Refresh before proceeding.");
  const [all, rules] = await Promise.all([listScheduleRaw(inst), listSeriesRules(inst)]);
  const sessions = all.filter((r) => r.recordType === "class-session" && r.classId === id).sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
  const relatedRules = rules.filter((r) => r.classId === id);
  const total = 1 + sessions.length + relatedRules.length;
  if (total > 80) throw httpError(413, `This class has ${sessions.length} sessions and ${relatedRules.length} recurring rules. Delete sessions in batches first; master-class deletion is limited to 80 total records.`);
  const signature = [`${master.id}:${master.version}`, ...sessions.map((r) => `${r.id}:${r.version}`), ...relatedRules.map((r) => `${r.effectiveFrom}:${r.updatedAt}`)].join("|");
  if (preview) return { classId: id, name: master.name, masterVersion: master.version, sessionCount: sessions.length, ruleCount: relatedRules.length, dates: sessions.map((r) => r.date), signature };
  if (input.confirm !== true || typeof input.signature !== "string" || input.signature !== signature) throw httpError(409, "Preview is missing or outdated. Review the class again.");
  const actions = [
    { Delete: { TableName: table4(), Key: { PK: schedulePK(inst), SK: scheduleSK(id) }, ConditionExpression: "#v=:v AND #type=:type", ExpressionAttributeNames: { "#v": "version", "#type": "recordType" }, ExpressionAttributeValues: { ":v": master.version, ":type": "class" } } },
    ...sessions.map((r) => ({ Delete: { TableName: table4(), Key: { PK: schedulePK(inst), SK: scheduleSK(r.id) }, ConditionExpression: "#v=:v AND #class=:class", ExpressionAttributeNames: { "#v": "version", "#class": "classId" }, ExpressionAttributeValues: { ":v": r.version, ":class": id } } })),
    ...relatedRules.map((r) => ({ Delete: { TableName: table4(), Key: { PK: seriesPK(inst), SK: seriesSK(id, r.effectiveFrom) }, ConditionExpression: "#updatedAt=:updatedAt", ExpressionAttributeNames: { "#updatedAt": "updatedAt" }, ExpressionAttributeValues: { ":updatedAt": r.updatedAt } } }))
  ];
  try {
    await db4.send(new TransactWriteCommand4({ TransactItems: actions }));
  } catch (e) {
    if (e.name === "TransactionCanceledException") throw httpError(409, "The class changed. Refresh and preview again.");
    throw e;
  }
  return { deleted: true, classId: id, sessionCount: sessions.length, ruleCount: relatedRules.length };
}
async function previewScheduleSeries(inst, id, input, claims) {
  if (inst === "shared") throw httpError(400, "Only academy classes have recurring series.");
  canAccess(claims, inst, true);
  const master = await getScheduleRecord(inst, id);
  if (!master || master.recordType !== "class") throw httpError(404, "Master class not found.");
  const parsed = parseSeriesChange(input, master);
  const candidate = { institution: inst, classId: id, effectiveFrom: parsed.effectiveFrom, ...parsed.effectiveUntil ? { effectiveUntil: parsed.effectiveUntil } : {}, changes: parsed.changes, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), updatedBy: String(claims.sub) };
  const [rules, result] = await Promise.all([listSeriesRules(inst), listScheduleRaw(inst)]);
  validateSeriesCandidate(master, rules, candidate);
  return calculateSeriesImpact(result, rules, candidate);
}
async function listScheduleRaw(inst) {
  const records = [];
  let key;
  do {
    const page = await db4.send(new QueryCommand5({ TableName: table4(), KeyConditionExpression: "PK=:pk", ExpressionAttributeValues: { ":pk": schedulePK(inst) }, ExclusiveStartKey: key, Limit: 250 }));
    records.push(...(page.Items || []).map(toPublic));
    key = page.LastEvaluatedKey;
    if (records.length > 3e3) throw httpError(413, "Too many schedule records.");
  } while (key);
  return records;
}
async function changeScheduleSeries(inst, id, input, claims) {
  if (inst === "shared") throw httpError(400, "Only academy classes have recurring series.");
  canAccess(claims, inst, true);
  const master = await getScheduleRecord(inst, id);
  if (!master || master.recordType !== "class") throw httpError(404, "Master class not found.");
  const { effectiveFrom, effectiveUntil, changes, expectedVersion } = parseSeriesChange(input, master);
  if (changes.teacherId) {
    const identity = await db4.send(new GetCommand4({ TableName: table4(), Key: { PK: "TEACHER_REGISTRY", SK: `TEACHER#${changes.teacherId}` }, ConsistentRead: true }));
    const teacher = identity.Item;
    if (!teacher || !teacher.active || !teacher.institutions?.includes(inst) || !matchesTeacherName(changes.teacher || "", teacher))
      throw httpError(400, "Selected teacher is not active or the name does not match its registered profile.");
  }
  const existing = await listSeriesRules(inst);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const rule = { institution: inst, classId: id, effectiveFrom, ...effectiveUntil ? { effectiveUntil } : {}, changes, updatedAt: now, updatedBy: String(claims.sub) };
  validateSeriesCandidate(master, existing, rule);
  const auditId = randomUUID4();
  try {
    await db4.send(new TransactWriteCommand4({ TransactItems: [
      { Update: {
        TableName: table4(),
        Key: { PK: schedulePK(inst), SK: scheduleSK(id) },
        UpdateExpression: "SET #version=:new, #updatedAt=:now",
        ConditionExpression: "#version=:old AND #type=:class",
        ExpressionAttributeNames: { "#version": "version", "#updatedAt": "updatedAt", "#type": "recordType" },
        ExpressionAttributeValues: { ":new": expectedVersion + 1, ":old": expectedVersion, ":now": now, ":class": "class" }
      } },
      { Put: {
        TableName: table4(),
        Item: { PK: seriesPK(inst), SK: seriesSK(id, effectiveFrom), entityType: "scheduleSeriesRule", ...rule },
        ConditionExpression: "attribute_not_exists(PK)"
      } },
      { Put: {
        TableName: table4(),
        Item: {
          PK: `AUDIT#${inst}`,
          SK: `SERIES-EDIT#${now}#${auditId}`,
          entityType: "audit",
          action: "changeClassSeries",
          classId: id,
          effectiveFrom,
          ...effectiveUntil ? { effectiveUntil } : {},
          changes,
          at: now,
          actor: claims.sub
        },
        ConditionExpression: "attribute_not_exists(PK)"
      } }
    ] }));
  } catch (e) {
    if (e.name === "TransactionCanceledException" || e.name === "ConditionalCheckFailedException")
      throw httpError(409, "Class version changed or a rule already exists for this date. Refresh and choose a new effective date.");
    throw e;
  }
  return { effectiveFrom, effectiveUntil, classId: id, changes, masterVersion: expectedVersion + 1 };
}

// src/teacherDirectory.ts
import { randomUUID as randomUUID5 } from "node:crypto";

// src/profilePhotos.ts
import { S3Client, HeadObjectCommand, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { DynamoDBClient as DynamoDBClient6 } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient as DynamoDBDocumentClient6, GetCommand as GetCommand5 } from "@aws-sdk/lib-dynamodb";
import {
  CognitoIdentityProviderClient,
  AdminGetUserCommand,
  AdminListGroupsForUserCommand,
  AdminUpdateUserAttributesCommand,
  ListUsersCommand
} from "@aws-sdk/client-cognito-identity-provider";

// src/adminPolicy.ts
var adminGroup = {
  raaga: "raagasudha-admin",
  sruti: "sruti-admin"
};
function canManageAdmins(claims, configuredSub) {
  return Boolean(configuredSub && claims.sub === configuredSub && permittedInstitutions(claims).length === 2);
}
function requireAdminManager(claims, configuredSub) {
  demandAnyAdmin(claims);
  if (!canManageAdmins(claims, configuredSub))
    throw httpError(403, "Only the designated Sadhana administrator may manage accounts.");
}
function readInstitution(value) {
  if (value !== "raaga" && value !== "sruti") throw httpError(400, "Select Raagasudha or Sruti.");
  return value;
}
function validateInvite(input) {
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).some((k) => !["email", "displayName", "institution"].includes(k)))
    throw httpError(400, "Unexpected invitation fields.");
  const email = typeof input.email === "string" ? input.email.trim().toLowerCase() : "";
  const displayName = typeof input.displayName === "string" ? input.displayName.trim().replace(/\s+/g, " ") : "";
  const institution = readInstitution(input.institution);
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw httpError(400, "Enter a valid administrator email.");
  if (!displayName || displayName.length > 100) throw httpError(400, "Enter a display name (up to 100 characters).");
  return { email, displayName, institution };
}
function validateAccessChange(input) {
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).some((k) => !["username", "institution", "grant"].includes(k)))
    throw httpError(400, "Unexpected account access fields.");
  const username = typeof input.username === "string" ? input.username.trim() : "";
  if (!username || username.length > 128 || /[\u0000-\u001f]/.test(username)) throw httpError(400, "Enter an existing Cognito username.");
  if (typeof input.grant !== "boolean") throw httpError(400, "Choose whether to grant or remove access.");
  return { username, institution: readInstitution(input.institution), grant: input.grant };
}
var adminTitles = ["", "Mr", "Mrs", "Ms", "Miss", "Dr", "Prof"];
function parseAdminTitle(value) {
  const name = value.trim().match(/^(Mr|Mrs|Ms|Miss|Dr|Prof)\.?\s+/i)?.[1] || "";
  return adminTitles.find((t) => t.toLowerCase() === name.toLowerCase()) || "";
}
function validateAdminProfile(input) {
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).some((k) => !["username", "firstName", "lastName", "title"].includes(k)))
    throw httpError(400, "Unexpected administrator profile fields.");
  const username = typeof input.username === "string" ? input.username.trim() : "";
  const firstName = typeof input.firstName === "string" ? input.firstName.trim().replace(/\s+/g, " ") : "";
  const lastName = typeof input.lastName === "string" ? input.lastName.trim().replace(/\s+/g, " ") : "";
  const title = typeof input.title === "string" ? input.title.trim() : "";
  if (!username || username.length > 128 || /[\u0000-\u001f]/.test(username))
    throw httpError(400, "Enter an existing Cognito username.");
  if (!firstName || !lastName || firstName.length > 60 || lastName.length > 60 || /[<>\u0000-\u001f]/.test(firstName + lastName) || `${firstName} ${lastName}`.length > 100)
    throw httpError(400, "Enter valid first and last names (up to 100 characters combined).");
  if (!adminTitles.includes(title))
    throw httpError(400, "Choose a valid name title.");
  if (`${title ? `${title} ` : ""}${firstName} ${lastName}`.length > 100)
    throw httpError(400, "Full name must be no more than 100 characters.");
  return { username, firstName, lastName, title };
}

// src/profilePhotoRules.ts
var PHOTO_MAX_BYTES = 220 * 1024;
var JPEG_SOF = /* @__PURE__ */ new Set([192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207]);
function photoKey(sub) {
  if (!/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(sub))
    throw httpError(400, "Invalid account identity for profile photo.");
  return `profiles/${sub.toLowerCase()}.jpg`;
}
function storedPhotoIsValid(ref, sub) {
  return typeof ref === "string" && ref === `s3:${photoKey(sub)}`;
}
function validatePhotoPayload(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw httpError(400, "Choose an image to upload.");
  const fields = value;
  if (Object.keys(fields).some((k) => !["base64", "username", "teacherId"].includes(k)))
    throw httpError(400, "Unexpected photo upload fields.");
  const raw = fields.base64;
  if (typeof raw !== "string" || raw.length > Math.ceil(PHOTO_MAX_BYTES / 3) * 4 + 8 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(raw))
    throw httpError(400, "Upload a valid JPEG under 220 KB.");
  const jpeg = Buffer.from(raw, "base64");
  if (jpeg.length < 32 || jpeg.length > PHOTO_MAX_BYTES || jpeg[0] !== 255 || jpeg[1] !== 216 || jpeg[2] !== 255 || jpeg[jpeg.length - 2] !== 255 || jpeg[jpeg.length - 1] !== 217)
    throw httpError(400, "Upload a JPEG under 220 KB.");
  let offset = 2;
  let dimensionsFound = false;
  while (offset + 4 < jpeg.length) {
    if (jpeg[offset] !== 255) break;
    while (jpeg[offset] === 255) offset++;
    const marker = jpeg[offset++];
    if (marker === 217 || marker === 218) break;
    if (marker === 216 || marker >= 208 && marker <= 215 || marker === 1) continue;
    if (offset + 2 > jpeg.length) break;
    const length = jpeg.readUInt16BE(offset);
    if (length < 2 || offset + length > jpeg.length) break;
    if (JPEG_SOF.has(marker)) {
      if (length < 7) break;
      const height = jpeg.readUInt16BE(offset + 3);
      const width = jpeg.readUInt16BE(offset + 5);
      if (width < 32 || height < 32 || width > 1024 || height > 1024)
        throw httpError(400, "Profile photo must be between 32 and 1024 pixels per side.");
      dimensionsFound = true;
      break;
    }
    offset += length;
  }
  if (!dimensionsFound) throw httpError(400, "JPEG dimensions could not be verified.");
  return jpeg;
}
function requireTeacherPhotoPermission(teacher, claims) {
  const institutes = teacher.institutions;
  if (!Array.isArray(institutes) || !institutes.length || institutes.some((i) => i !== "sruti" && i !== "raaga"))
    throw httpError(409, "Teacher institution assignment is invalid.");
  for (const institution of institutes) demandInstitution(claims, institution);
  const sub = teacher.cognitoSub;
  if (typeof sub !== "string" || !sub)
    throw httpError(409, "Link this teacher to an existing Sadhana login before uploading a photo.");
  photoKey(sub);
  return sub;
}

// src/profilePhotos.ts
var s3 = new S3Client({});
var cognito = new CognitoIdentityProviderClient({});
var db5 = DynamoDBDocumentClient6.from(new DynamoDBClient6({}));
var bucket = () => {
  const name = process.env.SADHANA_PROFILE_PHOTOS_BUCKET;
  if (!name) throw Error("SADHANA_PROFILE_PHOTOS_BUCKET not configured.");
  return name;
};
var pool = () => {
  const name = process.env.SADHANA_COGNITO_USER_POOL_ID;
  if (!name) throw Error("Cognito pool not configured.");
  return name;
};
var getSub = (a) => a?.find((v) => v.Name === "sub")?.Value || "";
async function signedProfilePhoto(sub) {
  if (!process.env.SADHANA_PROFILE_PHOTOS_BUCKET) return "";
  return getSignedUrl(s3, new GetObjectCommand({ Bucket: bucket(), Key: photoKey(sub) }), { expiresIn: 600 });
}
async function currentStaffDisplayName(sub) {
  photoKey(sub);
  const result = await cognito.send(new ListUsersCommand({
    UserPoolId: pool(),
    Filter: `sub = "${sub}"`,
    Limit: 2
  }));
  const user = result.Users?.[0];
  if (!user || result.Users?.length !== 1 || getSub(user.Attributes) !== sub)
    throw httpError(404, "Signed-in staff profile not found.");
  const attr2 = (key) => user.Attributes?.find((a) => a.Name === key)?.Value?.trim() || "";
  return (attr2("name") || [attr2("given_name"), attr2("family_name")].filter(Boolean).join(" ") || user.Username || "Staff").slice(0, 100);
}
async function ownProfilePhoto(sub) {
  if (!process.env.SADHANA_PROFILE_PHOTOS_BUCKET) return "";
  try {
    await s3.send(new HeadObjectCommand({ Bucket: bucket(), Key: photoKey(sub) }));
  } catch (error) {
    if (["NotFound", "NoSuchKey"].includes(error.name || "") || error.$metadata?.httpStatusCode === 404) return "";
    throw error;
  }
  return signedProfilePhoto(sub);
}
async function adminPhotoUrl(sub, picture2) {
  if (!sub || !storedPhotoIsValid(picture2, sub)) return "";
  return signedProfilePhoto(sub);
}
async function usernameBySub(sub) {
  photoKey(sub);
  const r = await cognito.send(new ListUsersCommand({
    UserPoolId: pool(),
    Filter: `sub = "${sub}"`,
    Limit: 2
  }));
  if (!r.Users?.length || r.Users.length !== 1 || !r.Users[0].Username || getSub(r.Users[0].Attributes) !== sub)
    throw httpError(404, "Signed-in staff account not found in Cognito.");
  return r.Users[0].Username;
}
async function adminTarget(username) {
  if (!username || username.length > 128 || /[\u0000-\u001f]/.test(username))
    throw httpError(400, "Choose a valid existing administrator username.");
  let user;
  try {
    user = await cognito.send(new AdminGetUserCommand({ UserPoolId: pool(), Username: username }));
  } catch (error) {
    if (error.name === "UserNotFoundException") throw httpError(404, "Administrator not found.");
    throw error;
  }
  if (!user.Enabled) throw httpError(409, "This administrator account is disabled.");
  const sub = getSub(user.UserAttributes);
  photoKey(sub);
  const groups = await cognito.send(new AdminListGroupsForUserCommand({ UserPoolId: pool(), Username: username }));
  if (!(groups.Groups || []).some((g) => g.GroupName === adminGroup.raaga || g.GroupName === adminGroup.sruti))
    throw httpError(403, "The target must be an existing academy administrator.");
  return { username, sub };
}
async function teacherPhotoTarget(teacherId, claims) {
  if (!/^TEACHER-[0-9a-f-]{36}$/i.test(teacherId))
    throw httpError(400, "Invalid teacher profile ID.");
  const table7 = process.env.SADHANA_TABLE_NAME;
  if (!table7) throw Error("SADHANA_TABLE_NAME is missing.");
  const response = await db5.send(new GetCommand5({
    TableName: table7,
    Key: { PK: "TEACHER_REGISTRY", SK: `TEACHER#${teacherId}` },
    ConsistentRead: true
  }));
  const teacher = response.Item;
  if (!teacher) throw httpError(404, "Registered teacher not found.");
  const sub = requireTeacherPhotoPermission(teacher, claims);
  return { sub, username: await usernameBySub(sub) };
}
async function uploadProfilePhoto(value, claims, mode) {
  if (mode === "administrator") requireAdminManager(claims, process.env.SADHANA_SUPER_ADMIN_SUB || "");
  const raw = value;
  if (mode === "me" && raw && ("username" in raw || "teacherId" in raw))
    throw httpError(400, "You may only upload your own profile photo.");
  if (mode === "teacher" && (!raw || "username" in raw || typeof raw.teacherId !== "string"))
    throw httpError(400, "Choose a linked teacher profile.");
  if (mode === "administrator" && (!raw || "teacherId" in raw))
    throw httpError(400, "Choose an existing administrator.");
  const jpeg = validatePhotoPayload(value);
  let sub = claims.sub || "";
  let username = "";
  if (mode === "administrator") {
    ({ sub, username } = await adminTarget(String(raw?.username || "")));
  } else if (mode === "teacher") {
    ({ sub, username } = await teacherPhotoTarget(raw.teacherId, claims));
  } else {
    username = await usernameBySub(sub);
  }
  const key = photoKey(sub);
  await s3.send(new PutObjectCommand({
    Bucket: bucket(),
    Key: key,
    Body: jpeg,
    ContentType: "image/jpeg",
    CacheControl: "private, max-age=60",
    ServerSideEncryption: "AES256"
  }));
  await cognito.send(new AdminUpdateUserAttributesCommand({
    UserPoolId: pool(),
    Username: username,
    UserAttributes: [{ Name: "picture", Value: `s3:${key}` }]
  }));
  console.info("Sadhana profile photo updated", { actor: claims.sub, target: sub, mode });
  return { photoUrl: await signedProfilePhoto(sub), updated: true };
}

// src/teacherDirectory.ts
import { DynamoDBClient as DynamoDBClient7 } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient as DynamoDBDocumentClient7,
  GetCommand as GetCommand6,
  QueryCommand as QueryCommand6,
  TransactWriteCommand as TransactWriteCommand5
} from "@aws-sdk/lib-dynamodb";
var db6 = DynamoDBDocumentClient7.from(
  new DynamoDBClient7({}),
  { marshallOptions: { removeUndefinedValues: true } }
);
var table5 = () => {
  if (!process.env.SADHANA_TABLE_NAME)
    throw Error("SADHANA_TABLE_NAME is missing");
  return process.env.SADHANA_TABLE_NAME;
};
var teacherKey = (id) => ({
  PK: "TEACHER_REGISTRY",
  SK: `TEACHER#${id}`
});
var identityKey = (sub) => ({
  PK: `TEACHER_SUB#${sub}`,
  SK: "LINK"
});
function present(raw, showSub) {
  const { PK, SK, entityType, ...record } = raw;
  if (!showSub) record.cognitoSub = "";
  return record;
}
async function findTeacher(id) {
  if (!/^TEACHER-[0-9a-f-]{36}$/i.test(id))
    throw httpError(400, "Invalid teacher ID.");
  const response = await db6.send(new GetCommand6({
    TableName: table5(),
    Key: teacherKey(id),
    ConsistentRead: true
  }));
  return response.Item ? present(response.Item, true) : null;
}
async function listTeachers(inst, claims) {
  demandViewInstitution(claims, inst);
  const found = [];
  let next;
  do {
    const response = await db6.send(new QueryCommand6({
      TableName: table5(),
      KeyConditionExpression: "PK=:pk AND begins_with(SK,:p)",
      ExpressionAttributeValues: {
        ":pk": "TEACHER_REGISTRY",
        ":p": "TEACHER#"
      },
      ExclusiveStartKey: next,
      Limit: 100,
      ConsistentRead: true
    }));
    found.push(...(response.Items || []).map((x) => present(x, true)));
    next = response.LastEvaluatedKey;
    if (found.length > 1e3)
      throw httpError(413, "Teacher directory size limit exceeded.");
  } while (next);
  const admin = permittedInstitutions(claims).includes(inst);
  const records = await Promise.all(found.filter((t) => t.institutions.includes(inst)).map(async (t) => ({
    ...admin ? t : { ...t, cognitoSub: "" },
    photoUrl: t.cognitoSub ? await signedProfilePhoto(t.cognitoSub) : ""
  })));
  return { records, more: false };
}
function parse2(input, claims, current) {
  if (!input || typeof input !== "object" || Array.isArray(input))
    throw httpError(400, "Teacher details must be an object.");
  const allowed = /* @__PURE__ */ new Set([
    "displayName",
    "institutions",
    "subjects",
    "aliases",
    "cognitoSub",
    "active",
    "expectedVersion"
  ]);
  if (Object.keys(input).some((k) => !allowed.has(k)))
    throw httpError(400, "Unknown teacher field.");
  const displayName = typeof input.displayName === "string" ? clean(input.displayName) : "";
  const rawInst = input.institutions;
  if (!Array.isArray(rawInst) || !rawInst.length || rawInst.length > 2 || rawInst.some((x) => x !== "raaga" && x !== "sruti"))
    throw httpError(400, "Select valid institutions.");
  const institutions = [...new Set(rawInst)];
  function strings(value, maxItems, maxChars) {
    if (!Array.isArray(value) || value.length > maxItems || value.some((x) => typeof x !== "string"))
      throw httpError(400, "Invalid teacher list field.");
    const items = [...new Set(value.map((x) => clean(x)))];
    if (items.some((x) => !x || x.length > maxChars))
      throw httpError(400, "Teacher list field is empty or too long.");
    return items;
  }
  const subjects = strings(input.subjects, 10, 60);
  const aliases = strings(input.aliases, 12, 100);
  const cognitoSub = typeof input.cognitoSub === "string" ? clean(input.cognitoSub) : "";
  if (!displayName || displayName.length > 100 || !subjects.length)
    throw httpError(400, "Name and teaching subject are required.");
  if (cognitoSub && !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(cognitoSub))
    throw httpError(400, "Use the Cognito sub, not an email.");
  if (typeof input.active !== "boolean")
    throw httpError(400, "Choose active or inactive.");
  const affected = [
    .../* @__PURE__ */ new Set([
      ...current?.institutions || [],
      ...institutions
    ])
  ];
  for (const inst of affected)
    demandInstitution(claims, inst);
  return {
    displayName,
    institutions,
    subjects,
    aliases,
    cognitoSub,
    active: input.active
  };
}
async function saveTeacher(input, claims, id) {
  demandAnyAdmin(claims);
  const current = id ? await findTeacher(id) : null;
  if (id && !current)
    throw httpError(404, "Teacher not found.");
  if (current && input.expectedVersion !== current.version)
    throw httpError(409, "Teacher changed; refresh before editing.");
  const parsed = parse2(input, claims, current || void 0);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const next = {
    ...parsed,
    id: current?.id || `TEACHER-${randomUUID5()}`,
    version: (current?.version || 0) + 1,
    createdAt: current?.createdAt || now,
    updatedAt: now
  };
  const writes = [{
    Put: {
      TableName: table5(),
      Item: {
        ...teacherKey(next.id),
        entityType: "teacher",
        ...next
      },
      ConditionExpression: current ? "#v=:old" : "attribute_not_exists(PK)",
      ...current ? {
        ExpressionAttributeNames: { "#v": "version" },
        ExpressionAttributeValues: { ":old": current.version }
      } : {}
    }
  }];
  if (current?.cognitoSub && current.cognitoSub !== next.cognitoSub) {
    writes.push({
      Delete: {
        TableName: table5(),
        Key: identityKey(current.cognitoSub),
        ConditionExpression: "teacherId=:id",
        ExpressionAttributeValues: { ":id": next.id }
      }
    });
  }
  if (next.cognitoSub && next.cognitoSub !== current?.cognitoSub) {
    writes.push({
      Put: {
        TableName: table5(),
        Item: {
          ...identityKey(next.cognitoSub),
          teacherId: next.id
        },
        ConditionExpression: "attribute_not_exists(PK)"
      }
    });
  }
  for (const inst of next.institutions) {
    writes.push({
      Put: {
        TableName: table5(),
        Item: {
          PK: `AUDIT#${inst}`,
          SK: `TEACHER#${now}#${randomUUID5()}`,
          entityType: "audit",
          action: current ? "updateTeacher" : "createTeacher",
          teacherId: next.id,
          actor: claims.sub,
          at: now
        },
        ConditionExpression: "attribute_not_exists(PK)"
      }
    });
  }
  try {
    await db6.send(new TransactWriteCommand5({
      TransactItems: writes
    }));
  } catch (e) {
    if (e.name === "TransactionCanceledException")
      throw httpError(
        409,
        "Teacher changed or Cognito account already linked."
      );
    throw e;
  }
  return { record: next };
}

// src/teacherLinking.ts
import { randomUUID as randomUUID6 } from "node:crypto";
import { DynamoDBClient as DynamoDBClient8 } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient as DynamoDBDocumentClient8, GetCommand as GetCommand7, QueryCommand as QueryCommand7, TransactWriteCommand as TransactWriteCommand6 } from "@aws-sdk/lib-dynamodb";
var db7 = DynamoDBDocumentClient8.from(new DynamoDBClient8({}), { marshallOptions: { removeUndefinedValues: true } });
var table6 = () => {
  if (!process.env.SADHANA_TABLE_NAME) throw Error("Missing Sadhana table name");
  return process.env.SADHANA_TABLE_NAME;
};
async function queryAll(pk) {
  const items = [];
  let key;
  do {
    const page = await db7.send(new QueryCommand7({ TableName: table6(), KeyConditionExpression: "PK=:pk", ExpressionAttributeValues: { ":pk": pk }, ExclusiveStartKey: key, ConsistentRead: true, Limit: 250 }));
    items.push(...page.Items || []);
    key = page.LastEvaluatedKey;
    if (items.length > 3e3) throw httpError(413, "Too many records for teacher linking.");
  } while (key);
  return items;
}
async function listTeacherLinks(inst, claims) {
  demandInstitution(claims, inst);
  const [{ records: teachers }, records, rules] = await Promise.all([
    listTeachers(inst, claims),
    queryAll(schedulePK(inst)),
    queryAll(seriesPK(inst))
  ]);
  const masters = records.filter((x) => x.recordType === "class");
  const masterById = new Map(masters.map((x) => [x.id, x]));
  const choices = teachers.filter((t) => t.active && t.institutions.includes(inst)).map(({ id, displayName, subjects, photoUrl }) => ({ id, displayName, subjects, photoUrl }));
  const rows = [
    ...masters.map((x) => ({
      classId: x.id,
      className: x.name,
      version: x.version,
      scope: "master",
      effectiveFrom: "",
      teacher: x.teacher || "",
      teacherId: x.teacherId || "",
      suggestedIds: suggestedTeacherIds(x.teacher || "", teachers)
    })),
    ...rules.filter((x) => x.changes?.teacher && masterById.has(x.classId)).map((x) => ({
      classId: x.classId,
      className: masterById.get(x.classId).name,
      version: masterById.get(x.classId).version,
      scope: "series",
      effectiveFrom: x.effectiveFrom,
      teacher: x.changes.teacher,
      teacherId: x.changes.teacherId || "",
      suggestedIds: suggestedTeacherIds(x.changes.teacher, teachers)
    }))
  ];
  return { institution: inst, teachers: choices, rows, more: false };
}
async function linkTeacherIdentity(inst, classId, body, claims) {
  demandInstitution(claims, inst);
  if (!body || typeof body !== "object" || Array.isArray(body) || Object.keys(body).some((k) => !["teacherId", "effectiveFrom", "expectedVersion"].includes(k)))
    throw httpError(400, "Unexpected teacher-link fields.");
  if (typeof body.teacherId !== "string" || !/^TEACHER-[0-9a-f-]{36}$/i.test(body.teacherId)) throw httpError(400, "Choose a registered teacher.");
  if (!Number.isInteger(body.expectedVersion)) throw httpError(400, "Expected class version required.");
  const fromValue = body.effectiveFrom;
  if (fromValue !== void 0 && (typeof fromValue !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(fromValue)))
    throw httpError(400, "Invalid series effective date.");
  const from = typeof fromValue === "string" ? fromValue : void 0;
  const master = await getScheduleRecord(inst, classId);
  if (!master || master.recordType !== "class") throw httpError(404, "Master class not found.");
  if (master.version !== body.expectedVersion) throw httpError(409, "Master class version changed. Refresh before linking.");
  const lookup = await db7.send(new GetCommand7({ TableName: table6(), Key: { PK: "TEACHER_REGISTRY", SK: `TEACHER#${body.teacherId}` }, ConsistentRead: true }));
  const teacher = lookup.Item;
  if (!teacher || !teacher.active || !teacher.institutions?.includes(inst)) throw httpError(400, "Teacher is not active in this institution.");
  const target = from === void 0 ? null : await db7.send(new GetCommand7({ TableName: table6(), Key: { PK: seriesPK(inst), SK: seriesSK(classId, from) }, ConsistentRead: true }));
  if (from !== void 0 && (!target?.Item || target.Item.classId !== classId)) throw httpError(404, "Effective-dated teacher rule not found.");
  const name = from === void 0 ? master.teacher : target.Item.changes?.teacher;
  if (!matchesTeacherName(name || "", teacher)) throw httpError(409, "Teacher name does not match this class or series rule. Change the teaching assignment separately before linking its identity.");
  const linked = from === void 0 ? master.teacherId : target.Item.changes?.teacherId;
  if (linked) throw httpError(409, "This assignment is already linked. Refresh to see the current teacher.");
  const now = (/* @__PURE__ */ new Date()).toISOString(), auditId = randomUUID6();
  const version = master.version;
  const transact = [
    { Update: {
      TableName: table6(),
      Key: { PK: schedulePK(inst), SK: scheduleSK(classId) },
      UpdateExpression: from === void 0 ? "SET teacherId=:teacherId, #v=:next, updatedAt=:now" : "SET #v=:next, updatedAt=:now",
      ConditionExpression: from === void 0 ? "#v=:old AND #teacher=:name AND attribute_not_exists(teacherId)" : "#v=:old AND #type=:class",
      ExpressionAttributeNames: from === void 0 ? { "#v": "version", "#teacher": "teacher" } : { "#v": "version", "#type": "recordType" },
      ExpressionAttributeValues: from === void 0 ? { ":old": version, ":next": version + 1, ":teacherId": teacher.id, ":name": name, ":now": now } : { ":old": version, ":next": version + 1, ":class": "class", ":now": now }
    } }
  ];
  if (from !== void 0) transact.push({ Update: {
    TableName: table6(),
    Key: { PK: seriesPK(inst), SK: seriesSK(classId, from) },
    UpdateExpression: "SET #changes.#teacherId=:teacherId, updatedAt=:now",
    ConditionExpression: "#changes.#teacher=:name AND attribute_not_exists(#changes.#teacherId)",
    ExpressionAttributeNames: { "#changes": "changes", "#teacher": "teacher", "#teacherId": "teacherId" },
    ExpressionAttributeValues: { ":teacherId": teacher.id, ":name": name, ":now": now }
  } });
  transact.push({ Put: { TableName: table6(), Item: {
    PK: `AUDIT#${inst}`,
    SK: `TEACHER-LINK#${now}#${auditId}`,
    entityType: "audit",
    action: "linkRegisteredTeacher",
    classId,
    teacherId: teacher.id,
    teacherName: teacher.displayName,
    ...from !== void 0 ? { effectiveFrom: from } : {},
    actor: claims.sub,
    at: now
  }, ConditionExpression: "attribute_not_exists(PK)" } });
  try {
    await db7.send(new TransactWriteCommand6({ TransactItems: transact }));
  } catch (e) {
    if (e.name === "TransactionCanceledException" || e.name === "ConditionalCheckFailedException") throw httpError(409, "Class or teacher assignment changed. Refresh and review again.");
    throw e;
  }
  return { classId, teacherId: teacher.id, effectiveFrom: from ?? null, masterVersion: version + 1, linked: true };
}

// src/adminDirectory.ts
import {
  CognitoIdentityProviderClient as CognitoIdentityProviderClient2,
  ListUsersInGroupCommand,
  AdminGetUserCommand as AdminGetUserCommand2,
  AdminListGroupsForUserCommand as AdminListGroupsForUserCommand2,
  AdminCreateUserCommand,
  AdminAddUserToGroupCommand,
  AdminRemoveUserFromGroupCommand,
  AdminUpdateUserAttributesCommand as AdminUpdateUserAttributesCommand2
} from "@aws-sdk/client-cognito-identity-provider";
var cognito2 = new CognitoIdentityProviderClient2({});
var pool2 = () => {
  const id = process.env.SADHANA_COGNITO_USER_POOL_ID;
  if (!id) throw Error("SADHANA_COGNITO_USER_POOL_ID is missing");
  return id;
};
var superSub = () => process.env.SADHANA_SUPER_ADMIN_SUB || "";
var attr = (attributes, key) => attributes?.find((a) => a.Name === key)?.Value || "";
var picture = (s) => /^(teachers|admins)\/[a-z0-9][a-z0-9-]{0,70}\.png$/.test(s) ? s : "";
var fullName = (a, username) => {
  const first = attr(a, "given_name").trim();
  const last = attr(a, "family_name").trim();
  const stored = attr(a, "name").trim();
  const fallback = [first, last].filter(Boolean).join(" ");
  const title = parseAdminTitle(stored);
  return (title ? `${title} ${fallback || stored.replace(/^(Mr|Mrs|Ms|Miss|Dr|Prof)\.?\s+/i, "")}` : fallback || stored) || username;
};
function cognitoError(error) {
  const name = error?.name;
  if (name === "UsernameExistsException") throw httpError(409, "An account already exists. Use Grant existing account.");
  if (name === "UserNotFoundException") throw httpError(404, "Cognito account not found. Check its exact username.");
  if (name === "InvalidParameterException") throw httpError(400, "Cognito rejected the account details. Check the pool settings and values.");
  throw error;
}
async function listAdministrators(instValue, claims) {
  const institution = readInstitution(instValue);
  demandInstitution(claims, institution);
  const records = [];
  let token;
  do {
    const result = await cognito2.send(new ListUsersInGroupCommand({
      UserPoolId: pool2(),
      GroupName: adminGroup[institution],
      Limit: 60,
      ...token ? { NextToken: token } : {}
    }));
    for (const u of result.Users || []) {
      if (!u.Username) continue;
      records.push({
        username: u.Username,
        sub: attr(u.Attributes, "sub"),
        displayName: fullName(u.Attributes, u.Username),
        title: parseAdminTitle(attr(u.Attributes, "name")),
        firstName: attr(u.Attributes, "given_name"),
        lastName: attr(u.Attributes, "family_name"),
        photo: picture(attr(u.Attributes, "picture")),
        photoUrl: await adminPhotoUrl(attr(u.Attributes, "sub"), attr(u.Attributes, "picture")),
        email: attr(u.Attributes, "email"),
        enabled: u.Enabled !== false,
        institution,
        status: u.UserStatus || ""
      });
    }
    token = result.NextToken;
    if (records.length >= 500 && token) throw httpError(413, "Administrator directory pagination limit exceeded.");
  } while (token);
  return { records, canManage: canManageAdmins(claims, superSub()) };
}
async function getAccount(username) {
  try {
    return await cognito2.send(new AdminGetUserCommand2({ UserPoolId: pool2(), Username: username }));
  } catch (error) {
    cognitoError(error);
  }
}
async function groupNames(username) {
  const groups = [];
  let token;
  do {
    const result = await cognito2.send(new AdminListGroupsForUserCommand2({
      UserPoolId: pool2(),
      Username: username,
      Limit: 60,
      ...token ? { NextToken: token } : {}
    }));
    groups.push(...(result.Groups || []).map((g) => g.GroupName || "").filter(Boolean));
    token = result.NextToken;
    if (groups.length >= 500 && token) throw httpError(413, "Too many account groups.");
  } while (token);
  return groups;
}
async function changeAdministratorAccess(raw, claims) {
  requireAdminManager(claims, superSub());
  const { username, institution, grant } = validateAccessChange(raw);
  const target = await getAccount(username);
  const targetSub = attr(target.UserAttributes, "sub");
  if (targetSub === superSub()) throw httpError(403, "Cannot change the protected super-admin account.");
  const group = adminGroup[institution];
  const already = (await groupNames(username)).includes(group);
  if (already === grant) return { username, institution, granted: grant, unchanged: true };
  try {
    if (grant) {
      await cognito2.send(new AdminAddUserToGroupCommand({ UserPoolId: pool2(), Username: username, GroupName: group }));
    } else {
      await cognito2.send(new AdminRemoveUserFromGroupCommand({ UserPoolId: pool2(), Username: username, GroupName: group }));
    }
  } catch (error) {
    cognitoError(error);
  }
  return { username, institution, granted: grant, unchanged: false };
}
async function inviteAdministrator(raw, claims) {
  requireAdminManager(claims, superSub());
  const { email, displayName, institution } = validateInvite(raw);
  let username;
  try {
    const result = await cognito2.send(new AdminCreateUserCommand({
      UserPoolId: pool2(),
      Username: email,
      UserAttributes: [{ Name: "email", Value: email }, { Name: "name", Value: displayName }],
      DesiredDeliveryMediums: ["EMAIL"]
    }));
    username = result.User?.Username || email;
  } catch (error) {
    cognitoError(error);
  }
  try {
    await cognito2.send(new AdminAddUserToGroupCommand({
      UserPoolId: pool2(),
      Username: username,
      GroupName: adminGroup[institution]
    }));
  } catch (error) {
    console.error("Admin invitation created but group grant failed", { errorName: error.name });
    throw httpError(409, `Invitation created for ${email}, but academy access could not be granted. Check the Cognito user before retrying.`);
  }
  return { username, institution, invited: true };
}
async function updateAdministratorProfile(raw, claims) {
  requireAdminManager(claims, superSub());
  const { username, firstName, lastName, title } = validateAdminProfile(raw);
  const target = await getAccount(username);
  if (target.Enabled === false) throw httpError(409, "This account is disabled.");
  const memberships = await groupNames(username);
  if (!memberships.includes(adminGroup.raaga) && !memberships.includes(adminGroup.sruti))
    throw httpError(403, "Only existing academy administrator profiles may be edited.");
  try {
    await cognito2.send(new AdminUpdateUserAttributesCommand2({
      UserPoolId: pool2(),
      Username: username,
      UserAttributes: [
        { Name: "given_name", Value: firstName },
        { Name: "family_name", Value: lastName },
        { Name: "name", Value: `${title ? `${title} ` : ""}${firstName} ${lastName}` }
      ]
    }));
  } catch (error) {
    cognitoError(error);
  }
  console.info("Administrator profile metadata updated", { username, actor: claims.sub });
  return { username, updated: true };
}

// src/lambda.ts
var json = (statusCode, body) => ({ statusCode, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }, body: JSON.stringify(body) });
var readPhotoJSON = (raw) => {
  if (raw.length > 31e4) throw httpError(413, "Profile photo upload exceeds the 220 KB image limit.");
  try {
    const value = JSON.parse(raw);
    return value;
  } catch {
    throw httpError(400, "Invalid photo upload request.");
  }
};
var readJSON = (raw) => {
  if (!raw) return {};
  if (raw.length > 25e3) throw httpError(413, "Request exceeds the permitted size.");
  try {
    return JSON.parse(raw);
  } catch {
    throw httpError(400, "Invalid JSON request.");
  }
};
function createHandler(repository) {
  return async (event) => {
    try {
      const requestMethod = event.requestContext?.http?.method ?? event.httpMethod;
      if (requestMethod === "OPTIONS") return { statusCode: 204, headers: { "cache-control": "no-store" }, body: "" };
      const claims = event?.requestContext?.authorizer?.jwt?.claims;
      if (!claims?.sub) return json(401, { error: "Authenticated Cognito access token required." });
      const groups = permittedInstitutions(claims);
      const viewed = viewableInstitutions(claims);
      if (!viewed.length) return json(403, { error: "Invitation-only staff role required." });
      const parts = apiRouteParts(event);
      const method = event.requestContext?.http?.method ?? event.httpMethod;
      const query = event.queryStringParameters ?? {};
      const inst = query.institution;
      if (method === "GET" && parts[0] === "me") return json(200, {
        subject: claims.sub,
        institutions: viewed,
        adminInstitutions: groups,
        role: groups.length ? "admin" : "viewer",
        displayName: await currentStaffDisplayName(claims.sub),
        photoUrl: await ownProfilePhoto(claims.sub)
      });
      if (parts[0] === "photos") {
        if (method !== "POST" || parts.length !== 2 || !["me", "administrator", "teacher"].includes(parts[1]))
          return json(405, { error: "Unsupported photo action." });
        const raw = event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : "";
        return json(200, await uploadProfilePhoto(readPhotoJSON(raw), claims, parts[1]));
      }
      if (parts[0] === "administrators") {
        if (method === "GET" && parts.length === 1)
          return json(200, await listAdministrators(inst, claims));
        const body = readJSON(event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : "");
        if (method === "POST" && parts.length === 2 && parts[1] === "invite")
          return json(201, await inviteAdministrator(body, claims));
        if (method === "POST" && parts.length === 2 && parts[1] === "access")
          return json(200, await changeAdministratorAccess(body, claims));
        if (method === "PATCH" && parts.length === 2 && parts[1] === "profile")
          return json(200, await updateAdministratorProfile(body, claims));
        return json(405, { error: "Unsupported administrator action." });
      }
      if (parts[0] === "teachers") {
        if (method === "GET" && parts.length === 1)
          return json(200, await listTeachers(inst, claims));
        if (method === "POST" && parts.length === 1) {
          const body = readJSON(
            event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : ""
          );
          return json(201, await saveTeacher(body, claims));
        }
        if (method === "PATCH" && parts.length === 2) {
          const body = readJSON(
            event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : ""
          );
          return json(200, await saveTeacher(body, claims, parts[1]));
        }
        return json(405, { error: "Unsupported teacher action." });
      }
      if (method === "GET" && parts[0] === "health") return json(200, { status: "ok", database: "configured", environment: "protected-api" });
      if (parts[0] === "recurring-classes") {
        const academy = query.institution;
        if (academy !== "raaga" && academy !== "sruti") throw httpError(400, "Choose an academy.");
        const body = readJSON(event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : "");
        if (method === "POST" && parts.length === 2 && parts[1] === "preview") return json(200, await previewRecurringClass(academy, claims, body));
        if (method === "POST" && parts.length === 1) return json(201, await createRecurringClass(academy, claims, body));
        return json(405, { error: "Unsupported recurring-class action." });
      }
      if (parts[0] === "events" && parts[1] === "shared") {
        const body = readJSON(event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : "");
        if (method === "POST" && parts.length === 2) return json(201, await saveSharedEvent(claims, body));
        if (method === "PATCH" && parts.length === 3) return json(200, await saveSharedEvent(claims, body, parts[2]));
        if (method === "DELETE" && parts.length === 3) return json(200, await cancelSharedEvent(claims, parts[2], body.expectedVersion));
        return json(405, { error: "Unsupported shared event action." });
      }
      if (parts[0] === "events") {
        const academy = query.institution;
        if (academy !== "raaga" && academy !== "sruti") throw httpError(400, "Choose an academy.");
        if (method === "GET" && parts.length === 1) return json(200, await listManagedEvents(academy, claims));
        const body = readJSON(event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : "");
        if (method === "POST" && parts.length === 1) return json(201, await saveManagedEvent(academy, claims, body));
        if (method === "PATCH" && parts.length === 2) return json(200, await saveManagedEvent(academy, claims, body, parts[1]));
        if (method === "DELETE" && parts.length === 2) return json(200, await cancelManagedEvent(academy, claims, parts[1], body.expectedVersion));
        return json(405, { error: "Unsupported event action." });
      }
      if (parts[0] === "schedule") {
        const target = query.institution;
        if (!["raaga", "sruti", "shared"].includes(target)) throw httpError(400, "Choose institution=raaga, sruti or shared.");
        if (parts[1] === "teacher-links") {
          if (method === "GET" && parts.length === 2 && target !== "shared") return json(200, await listTeacherLinks(target, claims));
          if (method === "PATCH" && parts.length === 3 && target !== "shared") {
            const linkBody = readJSON(event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : "");
            return json(200, await linkTeacherIdentity(target, parts[2], linkBody, claims));
          }
          return json(405, { error: "Unsupported teacher-link action." });
        }
        if (method === "GET" && parts.length === 1) return json(200, await listSchedule(target, claims));
        const body = readJSON(event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : "");
        if (method === "POST" && parts.length === 1) return json(201, await createSchedule(target, body, claims));
        if (method === "POST" && parts.length === 4 && parts[1] === "series" && parts[3] === "preview") return json(200, await previewScheduleSeries(target, parts[2], body, claims));
        if (method === "POST" && parts.length === 4 && parts[1] === "master" && parts[3] === "delete-preview") return json(200, await deleteMasterClass(target, parts[2], body, claims, true));
        if (method === "DELETE" && parts.length === 3 && parts[1] === "master") return json(200, await deleteMasterClass(target, parts[2], body, claims, false));
        if (method === "POST" && parts.length === 4 && parts[1] === "series" && parts[3] === "delete-preview") return json(200, await deleteSeriesSessions(target, parts[2], body, claims, true));
        if (method === "DELETE" && parts.length === 3 && parts[1] === "series") return json(200, await deleteSeriesSessions(target, parts[2], body, claims, false));
        if (method === "PATCH" && parts.length === 3 && parts[1] === "series") return json(200, await changeScheduleSeries(target, parts[2], body, claims));
        if (method === "PATCH" && parts.length === 2) return json(200, await changeSchedule(target, parts[1], body, claims));
        if (method === "DELETE" && parts.length === 2) return json(200, await deleteScheduleSession(target, parts[1], body, claims));
        return json(405, { error: "Unsupported schedule action." });
      }
      if (parts[0] === "calendar" && parts[1] === "middlesbrough") {
        if (!groups.includes("raaga")) throw httpError(403, "Raagasudha administrator role required.");
        if (method === "GET" && parts.length === 2) return json(200, await listMiddlesbrough());
        if (method === "POST" && parts[2] === "sync") return json(410, { error: "Google Calendar sync has been retired. Manage the timetable directly in Sadhana." });
        return json(405, { error: "Unsupported calendar action." });
      }
      if (method === "GET" && parts[0] === "identities" && parts[1] === "search") return json(200, await repository.identitySearch(claims, query.q));
      if (method === "GET" && parts[0] === "audit") {
        const institution = inst;
        if (!groups.includes(institution)) throw httpError(403, "Access denied.");
        const page = await repository.queryBase(`AUDIT#${institution}`, 100);
        return json(200, { records: page.items.map(({ PK, SK, entityType, ...r }) => r), more: page.nextPage });
      }
      const resource = parts[0];
      if (!RESOURCES.includes(resource)) return json(404, { error: "Unknown endpoint." });
      if (method === "GET" && parts.length === 1) return json(200, await repository.list(resource, inst, claims, { studentId: query.studentId }));
      const data2 = readJSON(event.body ? event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body : "");
      if (method === "POST" && parts.length === 1) return json(201, { record: await repository.create(resource, data2, inst, claims) });
      if (method === "PATCH" && resource === "practice" && parts.length === 3) {
        const args = { ...data2, institution: inst, studentId: parts[1], date: parts[2] };
        return json(200, { record: data2.action === "void" ? await repository.voidPractice(args, claims) : await repository.correctPractice(args, claims) });
      }
      if (method === "PATCH" && parts.length === 2) return json(200, { record: await repository.patch(resource, parts[1], data2, inst, claims) });
      if (method === "DELETE") return json(405, { error: "Physical deletion and archive transitions require additional policy and dependency checks. This API does not perform hard deletes." });
      return json(405, { error: "Method not supported." });
    } catch (error) {
      const e = error;
      const status = Number.isInteger(e?.status) ? e.status : 500;
      if (status === 500) console.error("Sadhana API internal error", { name: e.name, message: e.message });
      return json(status, { error: status === 500 ? "Unable to complete the operation." : e.message });
    }
  };
}
var cachedHandler;
var handler = async (event) => {
  if (!cachedHandler) cachedHandler = createHandler(new SadhanaRepository());
  return cachedHandler(event);
};
export {
  createHandler,
  handler
};
